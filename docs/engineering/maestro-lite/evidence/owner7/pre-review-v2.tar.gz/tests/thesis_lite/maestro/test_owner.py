from dataclasses import replace
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import socket
import subprocess
import time

import pytest

from xverse.argus import EvidenceStore
from xverse.maestro.admission import PermitSession, permit_digest
from xverse.maestro.owner import GateConnection, ReleaseOwner, StageSupervisor
from xverse.maestro.prbc import BoundaryDescriptor
from xverse.maestro.time import HostDeadline
from xverse_xdl.lifecycle import FileEvidenceJournal
from .test_admission import context
from .test_boundary import environment as environment
from .test_boundary import native as native
from .test_releasegate import guard_binary as guard_binary


def session(tmp_path, *, generation=1):
    prepared, result, resources, bindings, approvals = context()
    now = datetime.now(timezone.utc)
    bs, aps = [], []
    for b, a in zip(bindings, approvals):
        permit = replace(
            b.permit,
            not_before=now - timedelta(seconds=60),
            expires_at=now + timedelta(seconds=60),
        )
        bs.append(replace(b, generation=generation, permit=permit))
        aps.append(
            replace(
                a,
                generation=generation,
                permit_content_digest=permit_digest(permit),
                not_before=now - timedelta(seconds=60),
                expires_at=now + timedelta(seconds=60),
            )
        )
    return PermitSession(
        prepared,
        result,
        resources,
        run_id="fixture-run",
        bindings=bs,
        approvals=aps,
        now=now,
        journal=FileEvidenceJournal(tmp_path / "m3.jsonl"),
        initial_generation=generation,
    )


@pytest.fixture
def stack(tmp_path, environment):
    factory, spawn, root = environment
    permits = session(tmp_path)
    writer = EvidenceStore.open_run(
        tmp_path / "argus",
        run_id="fixture-run",
        plan=permits._result.plan,
        clocks={
            "host": {
                "domain": "host:host-session",
                "unit": "s",
                "value": time.monotonic(),
            },
            "utc": {
                "domain": "utc:host-session",
                "unit": "s",
                "value": datetime.now(timezone.utc).timestamp(),
            },
        },
    )
    manager, latch = factory(seconds=30, run_id="fixture-run")
    supervisor = StageSupervisor(manager, latch)
    owner = ReleaseOwner(permits, writer, supervisor, latch)
    children, connections = [], []

    def launch(binary, descriptor, lease=3):
        manager.create_frozen(descriptor)
        parent, child = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        parent.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
        artifact = "sha256:" + hashlib.sha256(Path(binary).read_bytes()).hexdigest()
        scope = owner.scope(descriptor.unit_id, descriptor, artifact)
        deadline_ns = time.monotonic_ns() + int(lease * 1e9)
        fd = manager._entries[descriptor.key].fd
        try:
            process = subprocess.Popen(
                [
                    str(binary),
                    str(fd),
                    str(child.fileno()),
                    str(
                        int(
                            manager._admission.teardown_deadline.monotonic_seconds * 1e9
                        )
                    ),
                    str(deadline_ns),
                    "500000000",
                    scope.hex(),
                    str(descriptor.creation_epoch),
                ],
                pass_fds=(fd, child.fileno()),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        finally:
            child.close()
        children.append((process, parent))
        connection = GateConnection(
            process,
            parent,
            scope=scope,
            epoch=descriptor.creation_epoch,
            lease_ns=deadline_ns,
            artifact_digest=artifact,
            latch=latch,
            deadline=HostDeadline("host-session", time.monotonic() + 1),
        )
        connections.append(connection)
        return connection

    yield owner, permits, writer, manager, spawn, launch
    owner.cancel()
    reaped = []
    for process, channel in children:
        channel.close()
        process.wait(timeout=3)
        reaped.append(process.pid)
    for connection in connections:
        connection.dispose()
    if writer.writer_state == "open":
        writer.abort(reason="owned integration test complete")
    receipt_dir = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if receipt_dir:
        (
            Path(receipt_dir)
            / (
                "owner-native-reaping-"
                + str(os.getpid())
                + "-"
                + tmp_path.name
                + ".json"
            )
        ).write_text(
            json.dumps({"all_gate_children_reaped": True, "count": len(reaped)})
        )


def deadline(seconds=3):
    return HostDeadline("host-session", time.monotonic() + seconds)


def test_real_claim_flush_stage_and_credential_checked_release(
    stack, native, guard_binary
):
    owner, permits, writer, manager, spawn, launch = stack
    unit_id = permits._prepared.units[0].unit_id
    descriptor = BoundaryDescriptor("fixture-run", unit_id, 1, "owned-boundary", 0)
    event_id = owner.commit_intent(unit_id, deadline())
    assert len(permits._journal.records) == 1
    assert permits._journal.records[0].details["generation"] == 1
    manager.create_frozen(descriptor)
    child, marker, line = spawn(native, manager, descriptor)
    assert line.startswith("CHILD ")
    gate = launch(guard_binary, descriptor)
    assert not select.select([marker], [], [], 0.02)[0]
    result = owner.release(unit_id, descriptor, gate, deadline())
    assert result.native_unfreeze_observed and not result.ready_for_execution
    assert select.select([marker], [], [], 1)[0] and os.read(marker, 1) == b"M"
    owner.cancel()
    gate.process.wait(timeout=2)
    assert manager.force_cleanup(descriptor).termination_observed
    assert child.wait(timeout=2) == 0
    manifest = writer.finalize()
    reader = EvidenceStore.read_run(writer._root)
    records = reader.records()
    assert records[0]["eventId"] == event_id
    payload = records[0]["extensions"]["xverse.maestro"]
    assert payload["action"] == "intent" and payload["generation"] == 1
    text = reader.export_jsonl()
    assert "private-test-nonce" not in text and "permitNonce" not in payload
    assert manifest.writer_state == "closed"


def test_explicit_generation_one_and_original_receipt_revalidation(tmp_path):
    permits = session(tmp_path)
    receipt = permits.claim_start_intent(
        permits._prepared.units[0].unit_id, now=datetime.now(timezone.utc)
    )
    permits.revalidate_start_intent(receipt, now=datetime.now(timezone.utc))
    with pytest.raises(ValueError):
        permits.revalidate_start_intent(
            replace(receipt), now=datetime.now(timezone.utc)
        )
