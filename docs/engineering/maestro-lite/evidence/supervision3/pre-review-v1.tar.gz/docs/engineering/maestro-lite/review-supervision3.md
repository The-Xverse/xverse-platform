# U3 worker-monitor review

Revision under review: ML3-SUPERVISION3-2026-10-18-v1, uncommitted overlay on c2997c0.
Same-agent separate read-only review; not an independent agent or factory review.
First verification: 48 component tests passed. No full ML3 runtime case executed.

Findings recorded before repair:

1. **SUP-REV-01, MAJOR:** `waitid` or select failure before the deadline returned
   unresolved without closing the shared latch. A second worker could therefore
   remain active in the same monitor context. Every uncertain monitoring outcome
   must fail close independently of journal/provider work. Add a direct counterexample.
2. **SUP-REV-02, MAJOR:** the retained slot kept the caller's `WatchLimits` object.
   Frozen dataclasses discourage mutation but do not snapshot caller state; an altered
   poll/TERM value could affect later monitoring. Reconstruct and privately retain
   validated immutable values at registration; test post-registration replacement.
3. **SUP-REV-03, MINOR:** `dispose_reaped` only checked pidfd exit readiness. A still
   unreaped zombie could lose its retained descriptor. Confirm nonblocking reaping
   (or exact exit plus no remaining parent wait record) before disposing. Cached
   unresolved observations must never be promoted or rewritten as normal success.
4. **SUP-REV-04, MINOR:** the ADR initially listed ML-SR-007/008 as implemented scope.
   Worker exit observation does not implement live generation probes/readiness or
   health cadence. Link this increment only as partial ML-SR-009/011/023/024 work;
   retain ownership/cleanup requirements as constraints and all full closures open.

Runtime limitations remain material: no helper-creation bound, actual launch fence,
supervisor-loss lease, C1, descendant containment, admitted bootstrap artifacts,
authenticated owner approvals, U5 integration, Argus coverage or full runtime proof.
Kernel calls and host scheduling are not hard-real-time bounded by Python. The
owner must supply an actual original child before dispatch, prevent competing waiters
and keep its private registry; type checks are not authenticated origin evidence.
