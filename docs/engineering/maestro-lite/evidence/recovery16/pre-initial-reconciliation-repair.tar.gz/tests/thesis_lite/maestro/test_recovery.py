"""Original issuer/journal reconstruction; no new Release or writer."""

from dataclasses import asdict, replace
import hashlib
import json
import os
from pathlib import Path
import signal

import pytest
from xverse.argus import EvidenceStore
from xverse.maestro.recovery import IssuerRecovery, RecoveryError
from xverse.maestro.run_closure import RunClosure
from xverse.maestro.teardown import ReverseTeardown
from .test_bootstrap import (
    boot_stack as boot_stack,
    supervisor_binary as supervisor_binary,
)
from .test_boundary import environment as environment, native as native
from .test_launcher import binaries as binaries, deadline
from .test_provider import runtime, second


def started(stack, *, two=False):
    facade, owner, descriptor, launcher, handle, gate, original = runtime(stack)
    if two:
        b, lb, hb, gb = second(stack, owner, original)
        facade.bind(lb, hb)
    assert facade.start(descriptor.unit_id, descriptor, gate, original).ready
    if two:
        assert facade.start(b.unit_id, b, gb, original).ready
    return facade, owner, descriptor, launcher, handle, gate, original


def reconciler(stack, facade, owner):
    return IssuerRecovery(
        stack[0],
        owner,
        policies=tuple(facade._policies.values()),
        operation_seconds=0.2,
    )


def retain(stack, result, name):
    output = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if output:
        from xverse_xdl.lifecycle import FileEvidenceJournal

        (Path(output) / f"recovery-public-{os.getpid()}-{name}.json").write_text(
            json.dumps(
                {
                    "result": asdict(result),
                    "events": EvidenceStore.read_run(
                        stack[4].parent / "argus"
                    ).records(),
                    "public_m3": FileEvidenceJournal(
                        stack[4].parent / "m3.jsonl"
                    ).public_records(),
                    "source_sha256": hashlib.sha256(
                        Path(__file__).read_bytes()
                    ).hexdigest(),
                }
            )
        )


def test_original_two_unit_recovery_retires_old_view_and_requires_new_health(
    boot_stack,
):
    facade, owner, a, launcher, handle, gate, original = started(boot_stack, two=True)
    old_sequence = facade._sequence
    before = EvidenceStore.read_run(boot_stack[4].parent / "argus").records()
    recovery = reconciler(boot_stack, facade, owner)
    active, terminal = deadline(1.5), deadline(7)
    result = recovery.reconcile(active, terminal)
    assert result.ordinary_reconciled and result.cleanup is None
    assert not result.fresh_ready and not result.lifecycle_complete
    assert recovery.view is not facade and not recovery.view.observations
    with pytest.raises(ValueError):
        facade.check_health(original, force=True)
    assert not owner.latch.cancelled
    assert all(
        v.ready and v.sequence > old_sequence
        for v in recovery.view.check_health(deadline(1), force=True)
    )
    after = EvidenceStore.read_run(boot_stack[4].parent / "argus").records()
    count = lambda events: sum(
        e.get("extensions", {}).get("xverse.maestro", {}).get("action") == "started"
        for e in events
    )
    assert count(after) == count(before) == 2
    assert recovery.reconcile(active, terminal) is result
    with pytest.raises(RecoveryError):
        recovery.reconcile(deadline(1), terminal)
    closed = RunClosure(boot_stack[0], teardown=ReverseTeardown(recovery.view)).close(
        deadline(6)
    )
    assert closed.cleanup_complete and closed.normal_unit_records_complete
    retain(boot_stack, result, "normal")


def test_reconstructed_view_and_original_owner_never_reopen_start(boot_stack):
    facade, owner, a, launcher, handle, gate, original = started(boot_stack)
    recovery = reconciler(boot_stack, facade, owner)
    assert recovery.reconcile(deadline(1), deadline(7)).ordinary_reconciled
    with pytest.raises(ValueError):
        recovery.view.start(a.unit_id, a, gate, deadline(1))
    with pytest.raises(ValueError):
        owner.release(a.unit_id, a, gate, deadline(1))
    assert not owner.latch.cancelled
    assert recovery.view.check_health(deadline(1), force=True)[0].ready


def test_staged_handle_without_normal_durable_outcome_is_cleanup_only(boot_stack):
    facade, owner, a, launcher, handle, gate, original = runtime(boot_stack)
    result = reconciler(boot_stack, facade, owner).reconcile(deadline(1), deadline(7))
    assert not result.ordinary_reconciled and result.cleanup is not None
    assert result.cleanup.cleanup_complete and owner.latch.cancelled
    assert not (boot_stack[4] / "source-binding.marker").exists()
    retain(boot_stack, result, "staged")


@pytest.mark.parametrize("fault", ["journal", "mirror", "handle"])
def test_durable_or_exact_handle_loss_blocks_recovery_and_preserves_original_cleanup(
    boot_stack, fault
):
    facade, owner, a, launcher, handle, gate, original = started(boot_stack)
    if fault == "journal":
        (boot_stack[4].parent / "m3.jsonl").unlink()
    elif fault == "mirror":
        root = boot_stack[4].parent / "argus"
        for path in root.glob("*.jsonl"):
            path.unlink()
    else:
        launcher._handle = replace(handle, opaque_id="f" * 64)
    result = reconciler(boot_stack, facade, owner).reconcile(deadline(1), deadline(7))
    assert not result.ordinary_reconciled and result.cleanup is not None
    assert all(b.released for b in result.cleanup.boundaries)
    assert owner.latch.cancelled
    retain(boot_stack, result, fault)


@pytest.mark.parametrize("target", ["owner", "view", "root"])
def test_normal_recovery_conflict_has_no_retirement_or_cancellation(boot_stack, target):
    facade, owner, a, launcher, handle, gate, original = started(boot_stack)
    recovery = reconciler(boot_stack, facade, owner)
    lock = {"owner": owner._lock, "view": facade._lock, "root": boot_stack[0]._lock}[
        target
    ]
    lock.acquire()
    try:
        with pytest.raises(RecoveryError):
            recovery.reconcile(deadline(1), deadline(7))
        assert not owner.latch.cancelled and facade.observation(a.unit_id).ready
        recovery.cancel()
        assert owner.latch.cancelled
    finally:
        lock.release()


def test_real_original_native_query_stall_returns_unknown_and_cleanup_only(boot_stack):
    facade, owner, a, launcher, handle, gate, original = started(boot_stack)
    signal.pidfd_send_signal(launcher.process._capability.fileno(), signal.SIGSTOP)
    result = reconciler(boot_stack, facade, owner).reconcile(deadline(1), deadline(7))
    assert not result.ordinary_reconciled and result.cleanup is not None
    assert result.cleanup.root_reaped and all(
        b.released for b in result.cleanup.boundaries
    )
    assert not result.cleanup.cleanup_complete
    retain(boot_stack, result, "issuer-stall")


def test_changed_host_session_rejects_without_borrowing_old_freshness(boot_stack):
    facade, owner, a, launcher, handle, gate, original = started(boot_stack)
    recovery = reconciler(boot_stack, facade, owner)
    with pytest.raises(RecoveryError):
        recovery.reconcile(
            replace(deadline(1), session="new-host-session"), deadline(7)
        )
    assert not owner.latch.cancelled and facade.observation(a.unit_id).ready
