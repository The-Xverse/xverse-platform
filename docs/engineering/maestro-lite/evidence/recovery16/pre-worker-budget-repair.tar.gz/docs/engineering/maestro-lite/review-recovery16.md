# Recovery read-only findings

18 October 2026. Separate same-agent component inspection; independent full-candidate review remains pending. Record findings before successor repairs.

1. MAJOR durable-status inspection: a genuine staged handle with no journal sample
   or normal start outcome should return a consumed-intent cleanup-only row, not
   the same error used for a mismatched durable handle. Existing conflicting handle
   evidence still rejects. Never fabricate a normal handle record.
2. MAJOR concurrency inspection: the draft releases its own recovery lock before
   failure cleanup and result publication. Retain that one nonblocking lock through
   cleanup/cache publication while releasing original owner/view/root locks before
   RunClosure. Concurrent recovery must not start a second reconciliation.
3. MINOR input/lint inspection: explicitly reject non-persistence original owners
   before accessing their child, and replace the expected-count test lambda with a
   function. No product permission or timeout is expanded.
4. Clarification: snapshot is read-only for the durable journal and Argus. It also
   retires the worker's prior in-memory positive applicability at the new view
   epoch. Preserve started/handle/history and sample sequencing; no old positive
   may satisfy a dependency after reconstruction. Same host process retains its
   original host clock; this view epoch does not establish process/new-session
   recovery or M1 release-epoch enforcement.
5. MAJOR independent-budget inspection: client preflight reserves follow-up
   probes/terminal capacity, but the original worker must independently check its
   actual remaining RPC capacity before retiring readiness at a recovery epoch.
   Add that check using its own request sequence/cap. Exercise real original
   health RPCs to approach the legacy cap, rather than changing a client counter.
