# Maestro Lite preparation increment

Status: **implementation candidate; U1/U6 plus partial U2; not accepted; no runtime admission**.
Owning baseline: `c2997c0f810d117cf45b2e34a4011b3ba7219494`.
Authoritative feature: `/home/jefferson/distributed_safety_critical_thesis/specs/024-maestro-lite-lifecycle/`.

## U2 successor

The successor at `/home/jefferson/xverse-platform-worktrees/maestro-lite-admission-20261018`
preserves the PREP1 worktree and adds `xverse.maestro.admission`. Use
`validate_permits` for pure exact-set validation and `PermitSession` only for
coordinator-side intent persistence through the actual M3 FileEvidenceJournal.
Every unit is validated before the session is returned; validity and source bindings
are checked again at claim time. Generation zero is supported here; resource restart
requires confirmed-release evidence and the later coordinator implementation.

`PermitApproval` represents private input facts from the future trusted admission
owner. The module cannot authenticate human approval or confer authority from those
fields. A returned `IntentReceipt` confirms a journal operation and always retains
`ready_for_execution=False`; it is neither a permit, an AFFA ticket nor lifecycle success.
The module provides no provider or workload callback.

The additive M3 `claim_intent` checks history and persists one intent under the same
thread/process locks. A small identity marker in the existing private lock file binds
the journal, lock and parent plus the retained byte prefix and minimum sequence.
Journal loss, replacement, truncation, malformed history and uncertain marker publication
cannot silently reset consumed permits. The marker contains no permit database.
These are journal-scoped guarantees for cooperating claim users, not a security boundary
against an actor able to rewrite both private files. Existing ordinary M3 append/read and
controller APIs retain their behavior; legacy check-then-append clients gain no implicit
cross-process atomicity guarantee.

Recognized exclusions are `legacy-execution` and closed `operation:`, `provider:` and
`realization:` values described in the code/design. Unknown or conflicting exclusions
reject. Exact approval bindings cover run/unit/execution/generation, full prepared value,
M3 plan, provider artifact/environment, artifact digests and private permit content.
Approval-owner binding to the actual admitted run/store, file rehash at launch, bootstrap,
C1 containment, deadlines, Argus flush and ticket issuance remain pending G1/G3/G4/G5 work.

See `ADR-ML3-ADMISSION-0001.md`, `unit-specification-admission2.md`,
`review-admission2.md` and `evidence/admission2/`. Earlier PREP1 records copied below
remain historical evidence for their exact subject; current U2 evidence is separate.

This increment implements the pure preparation and clock-validation parts of Phase 3.
It consumes an actual accepted `ExperimentPlanResult`, recompiles the immutable normalized
resources and compares the complete semantic plan, derives actual M3 catalog plans, and
projects a combined lifecycle graph. A rehashed caller modification is still rejected
when it does not reproduce the resources. No Scenario command becomes executable.

```python
from xverse.maestro import Limits, ProviderDescriptor, prepare

prepared = prepare(
    compiler_result,
    normalized_resources,
    provider_descriptors=provider_pins,
    limits=Limits(horizon_ticks=100),
)
assert prepared.ready_for_execution is False
```

The horizon in this example is an engineering input, not an AEB protocol threshold.
Provider descriptors require a closed provider ID/kind, explicit environment identity
and a SHA-256 artifact pin. Preparation never opens or verifies an executable artifact;
the pin is declared input identity, not artifact availability or provider admission.

## Implemented boundary

- One executable unit per bound component instance; unbound logical nodes remain containers.
- Exact catalog/provider/environment/artifact matching, duplicate and ambiguous selection rejection.
- Typed full resource/collection/element identities; source pointers resolve original XDL arrays.
- Start/Release/probe/readiness/completion joins, flow-owner readiness dependencies, explicit
  step completion dependencies, reverse teardown and impossible-window rejection.
- Deterministic, immutable preparation bytes and a SHA-256 digest. The increment uses its own
  `xverse.maestro.preparation.increment1` domain; it does not impersonate the complete v2
  lifecycle digest, whose admission, evidence obligations and helper pins are not implemented.
- Static eligible-step queries. Caller-supplied completed step IDs are scheduling input only;
  this function does not establish live readiness, health, ownership or permit validity.
- Integer-only simulation progression with zero/pauses, explicit horizon and rewind rejection;
  separate session-qualified host deadlines and UTC arithmetic. No host clock is read.

Finite proposed caps are 16 units, 128 steps, 128 distinct resource dependency pairs,
16,384 combined edges and a 10,000-tick horizon. The combined-edge cap bounds expansion of
phase and step dependencies; it is distinct from the resource-pair cap. Callers can narrow
these caps but cannot enlarge them. No measured timing or physical simulation fidelity is claimed.

## Pending boundary

There is no `start`, `stop`, `restart`, `reconcile`, `collect` or lifecycle-assessment API in
this increment. Actual process/simulated-provider orchestration, exact permits and durable
consumption, descriptor/C1 containment, watchdogs, current-generation readiness, emergency
teardown, Argus lifecycle obligations and offline coverage remain pending. A graph node
named `ready` describes a required predecessor; its existence is not evidence of readiness.

All 24 ML-SR requirements remain in scope. ML-SR-001–004 and ML-SR-015 receive partial
code/test evidence; ML-SR-023 receives additive packaging/regression evidence only. No
REF-002 parent is semantically validated or closed. See the thesis continuation record
and `review-increment1.md`; the complete P3 task list stays open.

The historical rejected candidate's false-success facade and process helper are excluded.
No historic admission, expired queue window, provider pin or fixture grants execution authority.
Any future factory run must originate in `/home/jefferson/x-verse_fabric` through
`automation/factory_start.py` with fresh controls, external supervision and the current
Sol/high/no-fallback model policy. Direct implementation does not create a factory run.

## Verification and maintenance

Run feature tests from this owning checkout with current source imports:

```bash
PYTHONPATH=src PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest tests/thesis_lite/maestro -q
python -m ruff check src/xverse/maestro tests/thesis_lite/maestro
```

For wheel verification use a fresh wheel build and an isolated environment with empty
PYTHONPATH, outside the checkout. Compare installed module bytes with source before
running copied tests. Hatchling force-includes `xverse` subpackages, so an editable
installation can retain a stale copy after source edits; it is insufficient by itself.
Existing XDL/M3/Argus consumers must pass from the exact source/wheel candidate.

Evidence logs and the final verification record identify actual checks and failures.
The initial full-suite environment failures and earlier review failures are retained.
No principal experiment, thesis result, PDF/DOCX generation, main update or external
publication occurs in this increment. Acceptance and merge require explicit author action.
