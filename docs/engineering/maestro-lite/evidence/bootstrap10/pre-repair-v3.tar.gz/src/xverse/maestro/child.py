"""Exact supported child capabilities; no discovery or metadata-based adoption."""

import os
import subprocess


def check_child(process, *, live=False):
    if type(process) is subprocess.Popen:
        return
    from .bootstrap import BootstrapChild

    if type(process) is not BootstrapChild:
        raise ValueError("ML-CHILD-CAPABILITY")
    process._holder()
    if live:
        process._ordinary()


def open_child_pidfd(process):
    check_child(process, live=True)
    if type(process) is subprocess.Popen:
        return os.pidfd_open(process.pid, 0)
    return os.dup(process._fd)


def wait_child(process, descriptor, *, consume=False):
    check_child(process)
    if type(process) is subprocess.Popen:
        flags = os.WEXITED | os.WNOHANG | (0 if consume else os.WNOWAIT)
        return os.waitid(os.P_PIDFD, descriptor, flags)
    return process._wait(descriptor, consume=consume)
