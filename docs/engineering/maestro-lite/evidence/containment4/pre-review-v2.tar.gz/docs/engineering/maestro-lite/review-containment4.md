# U4 boundary-component review

Candidate: ML3-CONTAINMENT4-2026-10-18-v1. Separate same-agent read-only review;
not independent full-candidate review. Findings recorded before repairs.

1. **CG-REV-01, MAJOR:** real kernel checks disprove the assumed `st_nlink == 0`
   removal predicate for retained cgroup directory descriptors. Successful rmdir
   stayed unresolved and fixture disposal failed too. First run: 19 passed,
   7 failed, 7 teardown errors. Use successful exact rmdir plus absence of the
   private name and kernel control files beneath the retained original FD; retain
   stable original identity through confirmation. Test clone3 rejection using the
   retained deleted FD. Do not substitute a missing path for original ownership.
2. **CG-REV-02, MAJOR:** the CP-02 reservation-only branch froze the allocation
   before checking it was empty. Reservation authority is only for verified empty,
   never-started allocation release, not freezing or terminating live members.
   Observe the original allocation without mutation first; reject any live/unknown
   membership without C1. Bound and retain this branch separately from full C1.
3. **CG-REV-03, MINOR:** huge integer time limits can raise OverflowError rather
   than the closed admission diagnostic. Validate positive finite limits without
   allowing bools or raw arithmetic exceptions.
4. **CG-REV-04, MAJOR:** the test harness did not persist a root allocation inventory
   before effects, and its teardown repeated the same incorrect removal predicate.
   Retain exact parent/root identity and source/command provenance in a fixture receipt,
   and make cleanup independent of library success. Missing ordinary C1 must remain
   unresolved; external component-test maintenance is not normal C1 recovery or a
   full ML3 runtime measure. Account for the first failed harness's empty roots.
5. **CG-REV-05, MAJOR:** the final Stage cancellation check and returned frozen
   commitment were not serialized with the short independent latch transition.
   Make that final commitment atomic with Cancel without holding the latch across I/O.
6. **CG-REV-06, MAJOR:** losing a registered C1 could fall back to the original
   empty-allocation reservation. CP-02 authority is only for the pre-C1 window;
   after C1 registration, losing it must remain unresolved even for an empty scope.
7. **CG-REV-07, MAJOR:** boundary errors retained unresolved accounting but did not
   close the shared start latch. Close it on partial/unknown failure, while allowing
   original valid cleanup to address its unchanged creation epoch.
8. **CG-REV-08, MAJOR:** a write used a deadline checked before identity/open calls;
   those calls can return after the bound. Recheck immediately before mutation and
   membership commitment. This is still not an atomic kernel lease across preemption.

After repairs, real kernel checks pass 38 cases with two test-assumption failures:
copy.copy is already denied by serialization refusal, and this kernel rejects cgroup
directory rename. Exercise copy refusal explicitly plus a fields-only forged holder;
use actual removal/recreation for the name-substitution fault. These are test repairs,
not permission to change the authority or kernel contract. Repaired harness receipts
show complete root removal and worker reaping for this run.

Next read-only pass: 40 component checks pass, including actual frozen birth,
leader-independent descendant scope, exact kill/remove and rejected clone through
the deleted retained descriptor. Two additional issues require successor repair:

9. **CG-REV-09, MAJOR:** parent validation preceded dup of the caller's FD number.
   Duplicate once first, validate that retained descriptor and close it on rejected
   admission. Future authenticated root binding remains G5; a raw FD is not approval.
10. **CG-REV-10, MINOR:** bounded control-file bytes still permitted a single numeric
    token longer than Python's integer conversion limit, escaping the closed error
    path. Bound token lengths/ranges and keep parse failures explicit/unresolved.

Open scope: authenticated bootstrap/original-owner admission, fixed exclusive root,
actual bounded helper supervision, M1/AFFA atomic Release/cancel and supervisor-loss
lease, U5 readiness/teardown, Argus evidence and full runtime/trace/acceptance. Freeze
alone is not a launch fence; model or component tests cannot close those gates.
