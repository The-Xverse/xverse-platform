# U4 boundary-component review

Candidate: ML3-CONTAINMENT4-2026-10-18-v1. Separate same-agent read-only review;
not independent full-candidate review. Findings recorded before repairs.

1. **CG-REV-01, MAJOR:** real kernel checks disprove the assumed `st_nlink == 0`
   removal predicate for retained cgroup directory descriptors. Successful rmdir
   stayed unresolved and fixture disposal failed too. First run: 19 passed,
   7 failed, 7 teardown errors. Use successful exact rmdir plus absence of the
   private name and kernel control files beneath the retained original FD; retain
   stable original identity through confirmation. Test clone3 rejection using the
   retained deleted FD. Do not substitute a missing path for original ownership.
2. **CG-REV-02, MAJOR:** the CP-02 reservation-only branch froze the allocation
   before checking it was empty. Reservation authority is only for verified empty,
   never-started allocation release, not freezing or terminating live members.
   Observe the original allocation without mutation first; reject any live/unknown
   membership without C1. Bound and retain this branch separately from full C1.
3. **CG-REV-03, MINOR:** huge integer time limits can raise OverflowError rather
   than the closed admission diagnostic. Validate positive finite limits without
   allowing bools or raw arithmetic exceptions.
4. **CG-REV-04, MAJOR:** the test harness did not persist a root allocation inventory
   before effects, and its teardown repeated the same incorrect removal predicate.
   Retain exact parent/root identity and source/command provenance in a fixture receipt,
   and make cleanup independent of library success. Missing ordinary C1 must remain
   unresolved; external component-test maintenance is not normal C1 recovery or a
   full ML3 runtime measure. Account for the first failed harness's empty roots.

Open scope: authenticated bootstrap/original-owner admission, fixed exclusive root,
actual bounded helper supervision, M1/AFFA atomic Release/cancel and supervisor-loss
lease, U5 readiness/teardown, Argus evidence and full runtime/trace/acceptance. Freeze
alone is not a launch fence; model or component tests cannot close those gates.
