from dataclasses import FrozenInstanceError, replace
import copy
import os
from pathlib import Path
import pickle
import select
import subprocess
import time
import uuid

import pytest

from xverse.maestro.prbc import (
    BoundaryAdmission,
    BoundaryDescriptor,
    BoundaryError,
    BoundaryLimits,
    ProcessBoundaryOps,
)
from xverse.maestro.supervisor import CancellationLatch
from xverse.maestro.time import HostDeadline


@pytest.fixture(scope="module")
def native(tmp_path_factory):
    target = tmp_path_factory.mktemp("boundary-native") / "boundary-fixture"
    command = [
        "cc",
        "-std=c11",
        "-O2",
        "-Wall",
        "-Wextra",
        "-Werror",
        str(Path(__file__).with_name("boundary_fixture.c")),
        "-o",
        str(target),
    ]
    subprocess.run(command, check=True, capture_output=True, timeout=20)
    return target


def _write(directory, name, data):
    fd = os.open(name, os.O_WRONLY, dir_fd=directory)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)


def _remove_owned_tree(parent_fd, name):
    """External test harness authority over its own fresh test subtree only."""
    fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY, dir_fd=parent_fd)
    try:
        _write(fd, "cgroup.kill", b"1")
        for item in os.scandir(fd):
            if item.is_dir(follow_symlinks=False):
                _remove_owned_tree(fd, item.name)
        deadline = time.monotonic() + 3
        while True:
            try:
                os.rmdir(name, dir_fd=parent_fd)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(0.005)
    finally:
        os.close(fd)


@pytest.fixture
def environment():
    # Discovery selects a test parent; it never grants runtime ownership/recovery.
    current = Path(
        "/sys/fs/cgroup" + Path("/proc/self/cgroup").read_text().strip().split("::")[1]
    )
    root_name = "maestro-component-" + uuid.uuid4().hex
    parent_fd = os.open(current, os.O_RDONLY | os.O_DIRECTORY)
    os.mkdir(root_name, mode=0o700, dir_fd=parent_fd)
    root_fd = os.open(root_name, os.O_RDONLY | os.O_DIRECTORY, dir_fd=parent_fd)
    monitors = []
    workers = []
    pipes = []

    def factory(*, seconds=4, reservation=True, epoch=0):
        facts = BoundaryAdmission(
            "run",
            "supervisor",
            "affa",
            "bootstrap-approval",
            "cleanup-approval",
            "reservation-approval" if reservation else None,
            HostDeadline("host-session", time.monotonic() + seconds),
            epoch,
        )
        latch = CancellationLatch()
        manager = ProcessBoundaryOps(root_fd, facts, latch)
        monitors.append(manager)
        return manager, latch

    def spawn(native, manager, descriptor, mode="single", retained_fd=None):
        entry = manager._entries[descriptor.key]
        cgfd = retained_fd if retained_fd is not None else entry.fd
        read, write = os.pipe()
        pipes.append(read)
        try:
            process = subprocess.Popen(
                [str(native), str(cgfd), str(write), mode],
                pass_fds=(cgfd, write),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
        finally:
            os.close(write)
        workers.append(process)
        assert select.select([process.stdout], [], [], 2)[0]
        line = process.stdout.readline().strip()
        return process, read, line

    yield factory, spawn, root_fd
    # Runtime library failures remain unresolved. Harness cleanup is separate evidence.
    for entry in list(os.scandir(root_fd)):
        if entry.is_dir(follow_symlinks=False):
            _remove_owned_tree(root_fd, entry.name)
    for process in workers:
        process.wait(timeout=3)
        process.stdout.close()
        process.stderr.close()
    for fd in pipes:
        os.close(fd)
    for manager in monitors:
        for entry in manager._entries.values():
            if entry.fd >= 0:
                manager.dispose_external_release(entry.descriptor)
        # Only dispose already-observed kernel identities; no runtime success inferred.
        if manager._root_fd >= 0:
            os.close(manager._root_fd)
            manager._root_fd = -1
    os.close(root_fd)
    os.rmdir(root_name, dir_fd=parent_fd)
    os.close(parent_fd)


def descriptor(unit="unit", epoch=0):
    return BoundaryDescriptor("run", unit, 0, "boundary-" + unit, epoch)


@pytest.mark.parametrize("field", ["generation", "creation_epoch"])
@pytest.mark.parametrize("bad", [True, -1, 1.5, "0", 2**80])
def test_invalid_descriptor_integers(field, bad):
    with pytest.raises(BoundaryError):
        replace(descriptor(), **{field: bad})


@pytest.mark.parametrize(
    "option",
    [
        "workload",
        "duration",
        "residual_children",
        "marker",
        "boundary_id",
        "epoch",
        "unknown",
    ],
)
def test_closed_options_reject_before_allocation(environment, option):
    factory, _, root = environment
    manager, _ = factory()
    before = tuple(os.listdir(root))
    with pytest.raises(BoundaryError, match="OPTIONS"):
        manager.create_frozen(descriptor(), **{option: True})
    assert tuple(os.listdir(root)) == before and not manager._entries


def test_real_cp03_empty_boundary_release(environment):
    factory, _, _ = environment
    manager, _ = factory()
    record = manager.create_frozen(descriptor())
    assert record.state == "frozen" and record.identity_retained
    assert record.membership_complete and record.residual_count == 0
    assert manager.residual_membership(descriptor()) == ()
    with pytest.raises(FrozenInstanceError):
        record.state = "released"
    result = manager.force_cleanup(descriptor())
    assert result.boundary_released and not result.identity_retained
    assert not result.termination_observed and not result.ready_for_execution
    assert manager.force_cleanup(descriptor()) is result
    with pytest.raises(BoundaryError, match="OBSERVATION-CLOSED"):
        manager.residual_membership(descriptor())
    manager.close()


def test_real_frozen_birth_force_cleanup_and_deleted_fd_fence(environment, native):
    factory, spawn, _ = environment
    manager, _ = factory()
    desc = descriptor()
    manager.create_frozen(desc)
    saved_fd = os.dup(manager._entries[desc.key].fd)
    try:
        worker, marker, line = spawn(native, manager, desc)
        assert line.startswith("CHILD "), line
        pid = int(line.split()[1])
        assert not select.select([marker], [], [], 0.03)[0], "frozen child ran marker"
        assert manager.residual_membership(desc) == (pid,)
        result = manager.force_cleanup(desc)
        assert result.boundary_released and result.termination_observed
        worker.wait(timeout=2)
        late, _, reply = spawn(native, manager, desc, retained_fd=saved_fd)
        assert reply.startswith("ERROR "), reply
        assert late.wait(timeout=2) == 77
    finally:
        os.close(saved_fd)


def test_real_leader_death_keeps_descendant_in_scope_and_sentinel_untouched(
    environment, native
):
    factory, spawn, _ = environment
    manager, _ = factory()
    desc, sentinel_desc = descriptor(), descriptor("sentinel")
    manager.create_frozen(desc)
    manager.create_frozen(sentinel_desc)
    leader, marker, line = spawn(native, manager, desc, "descendant")
    sentinel, sentinel_marker, sentinel_line = spawn(native, manager, sentinel_desc)
    assert line.startswith("CHILD ") and sentinel_line.startswith("CHILD ")
    leader_pid = int(line.split()[1])
    # Test-only thaw exercises membership. This is not an admitted Release method.
    _write(manager._entries[desc.key].fd, "cgroup.freeze", b"0")
    assert select.select([marker], [], [], 2)[0]
    first = os.read(marker, 1)
    assert first == b"M"
    assert select.select([marker], [], [], 2)[0]
    assert os.read(marker, 1) == b"D"
    leader.wait(timeout=2)  # fixture reaped its leader, descendant remains
    manager._freeze(manager._entries[desc.key])
    members = manager.residual_membership(desc)
    assert len(members) == 1 and leader_pid not in members
    assert manager.force_cleanup(desc).boundary_released
    assert manager.residual_membership(sentinel_desc) == (
        int(sentinel_line.split()[1]),
    )
    assert (
        sentinel.poll() is None and not select.select([sentinel_marker], [], [], 0)[0]
    )
    assert manager.force_cleanup(sentinel_desc).boundary_released


def test_cancel_before_stage_allocates_nothing(environment):
    factory, _, root = environment
    manager, latch = factory()
    latch.cancel("operator-stop")
    before = tuple(os.listdir(root))
    with pytest.raises(BoundaryError, match="CANCELLED"):
        manager.create_frozen(descriptor())
    assert tuple(os.listdir(root)) == before and not manager._entries


def test_cancel_during_allocation_retains_original_epoch_for_cleanup(
    environment, monkeypatch
):
    factory, _, _ = environment
    manager, latch = factory(epoch=8)
    original = os.mkdir

    def late_allocation(*args, **kwargs):
        original(*args, **kwargs)
        latch.cancel("during-stage")

    with monkeypatch.context() as patch:
        patch.setattr(os, "mkdir", late_allocation)
        with pytest.raises(BoundaryError, match="LATE-STAGE") as error:
            manager.create_frozen(descriptor(epoch=8))
    assert error.value.record.state == "partial"
    assert error.value.record.descriptor.creation_epoch == 8
    assert error.value.record.release_epoch == 9
    assert manager.force_cleanup(descriptor(epoch=8)).boundary_released


def test_fields_copies_and_replacement_registry_do_not_grant_authority(environment):
    factory, _, _ = environment
    manager, _ = factory()
    manager.create_frozen(descriptor())
    replacement, _ = factory()
    for value in [copy.copy(manager), replacement]:
        with pytest.raises(BoundaryError, match="OWNERSHIP"):
            value.force_cleanup(descriptor())
    with pytest.raises(TypeError):
        pickle.dumps(manager)
    manager._caps.clear()
    manager._reservations.clear()
    result = manager.force_cleanup(descriptor())
    assert result.state == "unresolved" and result.identity_retained
    assert not result.boundary_released


def test_failed_release_retains_identity_then_original_retry_succeeds(
    environment, monkeypatch
):
    factory, _, _ = environment
    manager, _ = factory()
    manager.create_frozen(descriptor())
    with monkeypatch.context() as patch:
        patch.setattr(
            os,
            "rmdir",
            lambda *args, **kwargs: (_ for _ in ()).throw(PermissionError()),
        )
        failed = manager.force_cleanup(descriptor())
    assert failed.state == "unresolved" and failed.identity_retained
    assert manager.force_cleanup(descriptor()).boundary_released


def test_missing_membership_is_unknown_not_empty(environment, monkeypatch):
    factory, _, _ = environment
    manager, _ = factory()
    manager.create_frozen(descriptor())
    original = manager._read

    def unreadable(entry, name):
        if name == "cgroup.procs":
            raise PermissionError()
        return original(entry, name)

    with monkeypatch.context() as patch:
        patch.setattr(manager, "_read", unreadable)
        with pytest.raises(BoundaryError) as error:
            manager.residual_membership(descriptor())
    assert error.value.record.state == "unresolved"
    assert not error.value.record.membership_complete
    assert manager.force_cleanup(descriptor()).boundary_released


def test_non_cgroup_parent_rejects_without_effect(tmp_path):
    fd = os.open(tmp_path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        facts = BoundaryAdmission(
            "run",
            "supervisor",
            "affa",
            "bootstrap",
            "cleanup",
            None,
            HostDeadline("host", time.monotonic() + 1),
            0,
        )
        with pytest.raises(BoundaryError, match="FILESYSTEM"):
            ProcessBoundaryOps(fd, facts, CancellationLatch())
        assert not list(tmp_path.iterdir())
    finally:
        os.close(fd)
