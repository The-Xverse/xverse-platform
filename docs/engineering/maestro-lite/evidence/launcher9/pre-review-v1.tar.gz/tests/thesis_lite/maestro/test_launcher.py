from dataclasses import replace
from datetime import datetime, timedelta, timezone
import hashlib
from importlib.resources import files
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

import pytest

from xverse.argus import EvidenceStore
from xverse.maestro.admission import PermitApproval, PermitBinding, permit_digest
from xverse.maestro.launcher import (
    CatalogLauncher,
    make_launch_recipe,
    sealed_recipe_fd,
)
from xverse.maestro.owner import GateConnection, ReleaseOwner, StageSupervisor
from xverse.maestro.persistence import (
    PersistenceClient,
    encode_configuration,
    sealed_input_fd,
)
from xverse.maestro.prbc import BoundaryDescriptor
from xverse.maestro.projection import ProviderDescriptor, prepare_lifecycle
from xverse.maestro.time import HostDeadline
from xverse_xdl.lifecycle import ExecutionPermit
from .test_preparation import compiled, documents
from .test_boundary import environment as environment


def deadline(seconds=3):
    return HostDeadline("host-session", time.monotonic() + seconds)


@pytest.fixture(scope="module")
def binaries(tmp_path_factory):
    root = tmp_path_factory.mktemp("catalog-launcher-native")
    definitions = [
        (
            "launcher",
            files("xverse.maestro").joinpath("native/catalog_launcher.c"),
            ["-lcrypto"],
        ),
        (
            "bound-gate",
            files("xverse.maestro").joinpath("native/lease_guard.c"),
            ["-DMAESTRO_RELEASE_GATE=1", "-DMAESTRO_BOUNDARY_ACK=1"],
        ),
        ("workload", Path(__file__).with_name("catalog_workload.c"), []),
    ]
    outputs = {}
    for name, source, extra in definitions:
        local = root / (name + ".c")
        local.write_bytes(source.read_bytes())
        binary = root / name
        cmd = [
            "cc",
            "-std=c11",
            "-O2",
            "-Wall",
            "-Wextra",
            "-Werror",
            str(local),
            *extra,
            "-o",
            str(binary),
        ]
        subprocess.run(cmd, check=True, capture_output=True, timeout=30)
        outputs[name] = binary
        receipt_dir = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
        if receipt_dir:
            target = Path(receipt_dir)
            target.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256(binary.read_bytes()).hexdigest()
            base = target / ("catalog-native-" + name + "-" + digest)
            base.with_suffix(".bin").write_bytes(binary.read_bytes())
            base.with_suffix(".json").write_text(
                json.dumps(
                    {
                        "command": cmd,
                        "returncode": 0,
                        "name": name,
                        "source_sha256": hashlib.sha256(local.read_bytes()).hexdigest(),
                        "binary_sha256": digest,
                    }
                )
            )
    return outputs


def configured(tmp_path, manager, binaries, mode="single"):
    work = tmp_path / "work"
    work.mkdir()
    docs = documents()
    deployment = docs["deployment.json"]["spec"]
    digest = "sha256:" + hashlib.sha256(binaries["workload"].read_bytes()).hexdigest()
    deployment["artifacts"][0].update(
        artifactKind="executable",
        digest=digest,
        sourceRef=binaries["workload"].as_uri(),
    )
    for binding in deployment["bindings"]:
        payload = binding["extensions"]["io.xverse.runtime.compatibility"]
        payload["provider"] = {"id": "maestro-process-v1", "kind": "process"}
        payload["process"] = {
            "executable": str(binaries["workload"]),
            "arguments": [binding["id"] + ".marker", mode],
            "workingDirectory": str(work),
            "environmentNames": ["MAESTRO_VISIBLE"],
            "inheritedHandles": "closed",
            "implicitShell": False,
        }
    result, resources = compiled(docs)
    helper_pin = (
        "sha256:" + hashlib.sha256(binaries["launcher"].read_bytes()).hexdigest()
    )
    prepared = prepare_lifecycle(
        result,
        resources,
        provider_descriptors=(
            ProviderDescriptor(
                "maestro-process-v1", "process", helper_pin, "isolated-fixture"
            ),
        ),
    )
    now = datetime.now(timezone.utc)
    bindings = []
    approvals = []
    for index, unit in enumerate(prepared.units):
        plan = unit.plan
        permit = ExecutionPermit(
            permit_id="owned-process-permit-" + str(index),
            nonce="private-process-nonce-" + str(index),
            plan_digest=plan.digest,
            catalog_identity=plan.catalog_identity,
            environment_identity=plan.environment_identity,
            permitted_actions=tuple(a.action_id for a in plan.actions),
            approval_evidence_ref="urn:xverse:test:process-approval:" + str(index),
            issuer_label="owned-test-approval",
            operation_classes=tuple(sorted({a.operation for a in plan.actions})),
            exclusions=("legacy-execution",),
            public_safety_classification="public-safe",
            not_before=now - timedelta(seconds=30),
            expires_at=now + timedelta(seconds=90),
        )
        binding = PermitBinding(
            unit.unit_id, "owned-process-execution-" + str(index), 1, permit
        )
        bindings.append(binding)
        approvals.append(
            PermitApproval(
                permit.approval_evidence_ref,
                permit.issuer_label,
                "fixture-run",
                unit.unit_id,
                binding.execution_id,
                1,
                prepared.lifecycle_digest,
                plan.digest,
                unit.provider.provider_id,
                unit.provider.kind,
                helper_pin,
                plan.environment_identity,
                plan.artifact_digests,
                permit_digest(permit),
                now - timedelta(seconds=30),
                now + timedelta(seconds=90),
            )
        )
    config = encode_configuration(
        prepared,
        result,
        resources,
        run_id="fixture-run",
        bindings=bindings,
        approvals=approvals,
        session="host-session",
        generation_deadline=manager._admission.teardown_deadline,
        journal_path=tmp_path / "m3.jsonl",
        evidence_root=tmp_path / "argus",
    )
    return config, helper_pin, work


@pytest.fixture
def launch_stack(tmp_path, environment, binaries, monkeypatch):
    factory, spawn, root = environment
    manager, latch = factory(seconds=35, run_id="fixture-run")
    config, helper_pin, work = configured(tmp_path, manager, binaries)
    parent, peer = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
    parent.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
    cfg = sealed_input_fd(config)
    process = subprocess.Popen(
        [
            sys.executable,
            "-I",
            "-m",
            "xverse.maestro.persistence_worker",
            str(peer.fileno()),
            str(cfg),
        ],
        pass_fds=(peer.fileno(), cfg),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    peer.close()
    os.close(cfg)
    client = PersistenceClient(process, parent, config, latch, deadline=deadline())
    owner = ReleaseOwner.from_persistence(
        client, StageSupervisor(manager, latch), latch
    )
    launchers = []
    gate_processes = []

    def launch(original=None):
        original = original or deadline(4.5)
        unit_id = config.prepared.units[0].unit_id
        owner.commit_intent(unit_id, original)
        descriptor = BoundaryDescriptor(
            "fixture-run", unit_id, 1, "catalog-boundary", 0
        )
        manager.create_frozen(descriptor)
        recipe = make_launch_recipe(
            owner,
            descriptor,
            environment={"MAESTRO_VISIBLE": "declared"},
            helper_artifact_digest=helper_pin,
            deadline=original,
        )
        source = sealed_recipe_fd(recipe)
        channel, other = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        channel.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
        boundary = manager._entries[descriptor.key].fd
        monkeypatch.setenv("MAESTRO_AMBIENT_SECRET", "not-inherited")
        child = subprocess.Popen(
            [
                str(binaries["launcher"]),
                str(boundary),
                str(other.fileno()),
                str(source),
            ],
            pass_fds=(boundary, other.fileno(), source),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        other.close()
        os.close(source)
        launcher = CatalogLauncher(
            child,
            channel,
            owner,
            recipe,
            helper_artifact_digest=helper_pin,
            deadline=original,
        )
        launchers.append(launcher)
        handle = launcher.stage(original)
        return descriptor, launcher, handle, original

    def gate(descriptor, original):
        boundary = manager._entries[descriptor.key].fd
        channel, other = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        channel.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
        pin = (
            "sha256:" + hashlib.sha256(binaries["bound-gate"].read_bytes()).hexdigest()
        )
        scope = owner.scope(descriptor.unit_id, descriptor, pin)
        until = time.monotonic_ns() + 4_000_000_000
        child = subprocess.Popen(
            [
                str(binaries["bound-gate"]),
                str(boundary),
                str(other.fileno()),
                str(config.generation_ns),
                str(until),
                "500000000",
                scope.hex(),
                "0",
            ],
            pass_fds=(boundary, other.fileno()),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        other.close()
        connection = GateConnection(
            child,
            channel,
            scope=scope,
            epoch=0,
            lease_ns=until,
            artifact_digest=pin,
            latch=latch,
            deadline=original,
            boundaries=manager,
            descriptor=descriptor,
        )
        gate_processes.append(connection)
        return connection

    yield owner, client, manager, config, work, launch, gate
    owner.cancel("test-catalog-teardown")
    for entry in manager._entries.values():
        if entry.state != "released":
            manager.force_cleanup(entry.descriptor)
    for launcher in launchers:
        launcher.cancel("test-catalog-teardown")
        observed = launcher.drain(deadline(1.5))
        assert observed.helper_reaped and observed.direct_child_reaped
        assert launcher.process.stderr.read() == b""
        launcher.process.stderr.close()
        launcher.dispose()
    for connection in gate_processes:
        connection.channel.close()
        connection.process.wait(timeout=2)
        assert connection.process.stderr.read() == b""
        connection.process.stderr.close()
        connection.dispose()
    if not client._failed and not client._aborted:
        client.abort(deadline(1))
    assert client.drain(deadline(1)).worker_reaped
    assert client.process.stderr.read() == b""
    client.process.stderr.close()
    client.dispose()
    receipt_dir = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if receipt_dir:
        (
            Path(receipt_dir)
            / ("catalog-children-" + str(os.getpid()) + "-" + tmp_path.name + ".json")
        ).write_text(
            json.dumps(
                {
                    "helpers_reaped": True,
                    "direct_children_reaped": True,
                    "launcher_count": len(launchers),
                    "gate_count": len(gate_processes),
                    "storage_count": 1,
                }
            )
        )


def test_actual_catalog_frozen_birth_bound_gate_exec_and_cleanup(
    launch_stack, tmp_path
):
    owner, client, manager, config, work, launch, gate = launch_stack
    descriptor, launcher, handle, original = launch()
    marker = work / "source-binding.marker"
    assert not marker.exists()
    before = launcher.observe(handle, deadline())
    assert before.leader_alive and not before.exec_pipe_closed and not before.running
    connection = gate(descriptor, original)
    result = owner.release(descriptor.unit_id, descriptor, connection, original)
    assert result.native_unfreeze_observed and not result.ready_for_execution
    until = time.monotonic() + 1
    while not marker.exists() and time.monotonic() < until:
        time.sleep(0.005)
    assert marker.read_text() == "EXEC\n"
    observed = launcher.observe(replace(handle), deadline())
    assert observed.running and not observed.ready_for_execution
    owner.cancel()
    assert manager.force_cleanup(descriptor).termination_observed
    drained = launcher.drain(deadline(1))
    assert (
        drained.helper_reaped
        and drained.direct_child_reaped
        and not drained.cleanup_complete
    )
    client.abort(deadline(1))
    reader = EvidenceStore.read_run(tmp_path / "argus")
    assert (
        reader.manifest["writerState"] == "failed"
        and reader.records()[0]["extensions"]["xverse.maestro"]["generation"] == 1
    )
