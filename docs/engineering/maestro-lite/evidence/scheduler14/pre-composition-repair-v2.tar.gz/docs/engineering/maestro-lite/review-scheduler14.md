# Scheduler read-only integration findings

18 October 2026. Same-agent separate inspection, not independent full-candidate review.
Record findings before the successor edits that address them.

1. MAJOR composition finding: OutcomeJournal numbers its producer from len(events),
   but that shared retained-mirror register also contains teardown and future step
   producer events. A later probe after a scoped stop/step record would jump its
   producer sequence and fail the client's exact next-sequence check. Retain the
   shared mirror register but give the outcomes producer its own counter. Exercise
   actual interleaved step/tick/stop and health records in full dispatcher tests.
2. ADVISORY scope: already-issued unit composition does not establish initial
   bootstrap/environment admission, full helper closure, restart/recovery, U7/U8,
   global M1, nine runtime cases or independent full review/acceptance. Preserve all
   open full P3 tasks and downstream phases 4–9.
3. MINOR initial expected fixture: 20 active seconds in the two-unit fixture still
   fits 128 calls (100 worst-case calls); the test wrongly expects rejection.
   Use 40 seconds for the over-cap control and retain exact independent counts.
4. MAJOR pure-admission inspection: individually finite, tiny positive cadence
   values can make active_seconds/period overflow to infinity before ceil().
   Reject nonfinite or over-cap derived slot counts explicitly with ScheduleError
   before constructing health obligations. Do not loosen any cadence or limit.
5. MINOR test inspection: the renewal-positive test immediately infers running
   from a Release ACK plus one Query. ACK only proves unfreeze; exec may still be
   pending. Verify through the actual bounded readiness facade before asserting
   running. This changes no product timeout or application-readiness claim.
6. MAJOR admission integration: a missing Query needs a normal factual failure
   record in addition to the unit terminal disposition when storage remains usable.
   Reserve at most one such diagnostic per admitted unit before any Release and
   enforce that one-use limit in the forthcoming schedule journal. It cannot mint
   a successful probe or replace a missing normal outcome.
7. MAJOR verification harness: composition-v1 reused an installed wheel built before
   the failure-diagnostic admission reserve changed. Its worker independently rejects
   the changed schedule bytes, so six scheduled cases fail at Init as expected for
   that mismatch. Do not count the mixed-source run as current verification. Rebuild
   and reinstall the actual wheel after product changes, record module identity,
   and repeat the affected composition checks. Preserve the raw failed run.
8. MAJOR actual scoped-composition counterexample: after a dependent's confirmed
   cleanup, _jobs still compares its retained launcher recipe with a missing live
   descriptor, rejecting later phases/final teardown. Skip exactly the original
   controller's already-confirmed cleaned units in the live-job snapshot; preserve
   their cached historical facts in final reverse order. Do not skip unknown or
   unconfirmed resources or adopt a replacement descriptor.
