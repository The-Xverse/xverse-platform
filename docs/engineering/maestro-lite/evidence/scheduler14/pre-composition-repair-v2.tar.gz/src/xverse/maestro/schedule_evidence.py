"""Original-worker finite tick source and schedule evidence; no launch authority."""

from datetime import datetime, timezone
import hashlib
import math
import time

from .persistence import PersistenceError


class ScheduleJournal:
    def __init__(self, evidence, plan):
        self.evidence, self.plan = evidence, plan
        self.cursor, self.tick, self.pending = 0, 0, None
        self.sequence = 0
        self.last_event = None

    def pull(self, body, deadline, check):
        check(deadline)
        if (
            type(body) is not dict
            or set(body) != {"index", "previous"}
            or type(body["index"]) is not int
            or body["index"] != self.cursor + 1
            or type(body["previous"]) is not int
            or body["previous"] != self.tick
            or self.pending is not None
            or self.cursor >= len(self.plan.ticks)
        ):
            raise PersistenceError("ML-SCHEDULE-TICK-REQUEST")
        self.tick = self.plan.ticks[self.cursor]
        self.pending = self.cursor + 1
        return {
            "index": self.pending,
            "tick": self.tick,
            "schedule_digest": self.plan.digest,
        }

    def record(self, body, claims, operation, deadline, check):
        check(deadline)
        if (
            type(body) is not dict
            or set(body) != {"kind", "index", "tick", "observed_at"}
            or body["kind"] != "tick-complete"
            or type(body["index"]) is not int
            or body["index"] != self.pending
            or type(body["tick"]) is not int
            or body["tick"] != self.tick
        ):
            raise PersistenceError("ML-SCHEDULE-TICK-RECORD")
        payload = {
            "schemaVersion": "2.0",
            "lifecycleDigest": "sha256:" + self.plan.lifecycle_digest,
            "runId": self.evidence.permits._run_id,
            "sessionId": deadline.session,
            "scope": "run",
            "unitId": None,
            "generation": 0,
            "operationId": operation,
            "action": "validate",
            "outcome": "succeeded",
            "obligationId": "tick-" + str(self.pending),
            "sourceRefs": [
                {
                    "kind": "admitted-lifecycle",
                    "id": "schedule-admission",
                    "sequence": 0,
                    "sha256": "sha256:"
                    + hashlib.sha256(self.plan.canonical_bytes).hexdigest(),
                }
            ],
            "dependencies": [],
        }
        fields = self._append(payload, body["observed_at"], claims, deadline, check)
        self.cursor += 1
        self.pending = None
        return {
            "kind": "tick-complete",
            "index": self.cursor,
            "tick": self.tick,
            "event": fields,
        }

    def _append(self, payload, observed_at, claims, deadline, check):
        try:
            valid = (
                type(observed_at) in (int, float)
                and math.isfinite(observed_at)
                and 0 <= time.monotonic() - observed_at <= 5
            )
        except OverflowError:
            valid = False
        if not valid:
            raise PersistenceError("ML-SCHEDULE-OBSERVATION")
        self.evidence._history(claims)
        self.evidence._mirrors(claims)
        self.evidence.reserve_event(claims)
        check(deadline)
        now = datetime.now(timezone.utc)
        fields = {
            "eventId": payload["operationId"] + "-schedule",
            "producerId": "maestro.scheduler14",
            "eventKind": "annotation",
            "producerSequence": self.sequence + 1,
            "correlationId": self.evidence.permits._run_id,
            "causationId": self.last_event,
            "clocks": {
                "host": {
                    "domain": "host:" + deadline.session,
                    "unit": "s",
                    "value": observed_at,
                },
                "utc": {
                    "domain": "utc:" + deadline.session,
                    "unit": "s",
                    "value": now.timestamp(),
                },
                "simulation": {
                    "domain": self.evidence.permits._prepared.clock.domain,
                    "unit": "tick",
                    "value": self.tick,
                },
            },
            "annotation": {"text": "Maestro scheduled " + payload["action"]},
            "extensions": {"xverse.maestro": payload},
        }
        ordinal = self.evidence.writer.append_event(
            event_id=fields["eventId"],
            producer_id=fields["producerId"],
            event_kind="annotation",
            producer_sequence=fields["producerSequence"],
            correlation_id=fields["correlationId"],
            causation_id=fields["causationId"],
            clocks=fields["clocks"],
            annotation=fields["annotation"],
            extensions=fields["extensions"],
        )
        check(deadline)
        self.evidence.writer.flush_buffer()
        check(deadline)
        fields["ingestionOrdinal"] = ordinal
        self.evidence.events[fields["eventId"]] = fields
        self.evidence._mirrors(claims)
        check(deadline)
        self.sequence += 1
        self.last_event = fields["eventId"]
        return fields
