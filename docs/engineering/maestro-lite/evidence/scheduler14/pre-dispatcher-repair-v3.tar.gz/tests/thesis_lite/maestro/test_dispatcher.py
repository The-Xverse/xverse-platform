"""Actual full-phase declared dispatch over original staged processes."""

import copy
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import time

import pytest
from xverse.argus import EvidenceStore
from xverse.argus.schema import canonical_bytes
from xverse.maestro.dispatcher import FiniteDispatcher
from xverse.maestro.projection import Limits
from xverse.maestro.providers import ProcessReadiness, ProbePolicy
from xverse.maestro.schedule_plan import admit_schedule
from xverse.maestro.time import HostDeadline
from .test_bootstrap import (
    boot_stack as boot_stack,
    supervisor_binary as supervisor_binary,
)
from .test_boundary import environment as environment, native as native
from .test_launcher import binaries as binaries
from .test_provider import second


def full_stack(request, monkeypatch, *, pauses=1, duration=0):
    from . import test_bootstrap, test_launcher

    docs = test_launcher.documents

    def documents():
        data = docs()
        scenario = data["scenario.json"]["spec"]
        template = scenario["steps"][0]
        definitions = [
            ("prepare-source", "source", "prepare", 0, []),
            ("prepare-sink", "sink", "prepare", 0, []),
            ("start-source", "source", "start", 0, ["prepare-source"]),
            ("start-sink", "sink", "start", duration, ["prepare-sink", "start-source"]),
            ("observe-source", "source", "observe", 1, ["start-source"]),
            ("observe-sink", "sink", "observe", 1, ["start-sink"]),
            ("stop-sink", "sink", "stop", 2, ["observe-sink"]),
            ("cleanup-sink", "sink", "cleanup", 2, ["stop-sink"]),
            ("stop-source", "source", "stop", 3, ["observe-source"]),
            ("cleanup-source", "source", "cleanup", 3, ["stop-source"]),
        ]
        steps = []
        for name, unit, phase, tick, deps in definitions:
            item = copy.deepcopy(template)
            item["id"] = name
            item["targetRef"]["element"] = unit + "-instance"
            item["actionKind"] = "validate" if phase == "prepare" else phase
            item["action"]["operation"] = item["actionKind"]
            item["schedule"]["at"] = tick
            item["schedule"]["tolerance"]["value"] = (
                duration if name == "start-source" else 0
            )
            ext = item["extensions"]["io.xverse.experiment"]
            ext["target"]["element"] = name
            ext["phase"] = phase
            ext["dependsOn"] = deps
            ext["duration"]["value"] = duration if name == "start-source" else 0
            steps.append(item)
        scenario["steps"] = steps
        return data

    monkeypatch.setattr(test_launcher, "documents", documents)
    prepare = test_launcher.prepare_lifecycle
    monkeypatch.setattr(
        test_launcher,
        "prepare_lifecycle",
        lambda *a, **kw: prepare(*a, limits=Limits(horizon_ticks=3), **kw),
    )
    configure = test_bootstrap.configured

    def configured(*args, **kwargs):
        config, pin, work = configure(*args, **kwargs)
        plan = admit_schedule(
            config.prepared,
            policies=tuple(
                ProbePolicy(u.unit_id, 2, 1.5, 0.15) for u in config.prepared.units
            ),
            ticks=(0,) * pauses + (1, 2, 3),
            active_seconds=4.8 if pauses > 1 else 2.5,
            operation_seconds=0.15,
            poll_seconds=0.05,
            request_limit=1024,
        )
        body = json.loads(config.private_bytes)
        body["schedule"] = json.loads(plan.canonical_bytes)
        return (
            replace(config, schedule=plan, private_bytes=canonical_bytes(body)),
            pin,
            work,
        )

    monkeypatch.setattr(test_bootstrap, "configured", configured)
    return request.getfixturevalue("boot_stack")


def dispatcher(stack):
    owner, storage, a, la, ha, ga, original = stack[6]()
    b, lb, hb, gb = second(stack, owner, original)
    facade = ProcessReadiness(owner, policies=storage.schedule.policies)
    facade.bind(la, ha)
    facade.bind(lb, hb)
    return FiniteDispatcher(facade, stack[0], gates=((a.unit_id, ga), (b.unit_id, gb)))


def ends(driver):
    active = HostDeadline(
        driver.owner.session, time.monotonic() + driver.plan.active_seconds - 0.05
    )
    return active, HostDeadline(
        driver.owner.session,
        active.monotonic_seconds + driver.plan.terminal_reserve_seconds + 0.01,
    )


def test_full_five_phase_dispatch_records_actual_outcomes_and_dispositions(
    request, monkeypatch
):
    stack = full_stack(request, monkeypatch)
    driver = dispatcher(stack)
    bounds = ends(driver)
    trace = []
    for method in ("_send", "_effect"):
        original = getattr(FiniteDispatcher, method)

        def observed(self, *args, _method=method, _original=original, **kwargs):
            began = time.monotonic()
            try:
                return _original(self, *args, **kwargs)
            except Exception as error:
                trace.append(
                    {
                        "method": _method,
                        "kind": str(args[0]) if _method == "_send" else args[0].step_id,
                        "elapsed": time.monotonic() - began,
                        "error_type": type(error).__name__,
                        "diagnostic": str(error),
                    }
                )
                raise

        monkeypatch.setattr(FiniteDispatcher, method, observed)
    result = driver.run(*bounds)
    receipt = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if receipt:
        (Path(receipt) / "dispatcher-operation-observations.json").write_text(
            json.dumps(trace, indent=2)
        )
    assert result.execution_succeeded and result.terminal_recorded, result
    assert len(result.steps) == 10 and all(
        s.disposition == "completed" and s.normal_recorded for s in result.steps
    )
    assert (
        result.cleanup.unit_cleanup_complete and result.cleanup.normal_records_complete
    )
    assert not result.lifecycle_complete and not result.ready_for_execution
    assert driver.run(*bounds) is result
    with pytest.raises(ValueError):
        driver.run(
            HostDeadline(driver.owner.session, bounds[0].monotonic_seconds + 0.01),
            bounds[1],
        )
    events = EvidenceStore.read_run(stack[4].parent / "argus").records()
    from jsonschema import Draft202012Validator

    validator = Draft202012Validator(
        json.loads(
            Path(__file__).with_name("lifecycle-payload-v2.schema.json").read_text()
        )
    )
    phases = []
    dispositions = []
    for event in events:
        payload = event["extensions"]["xverse.maestro"]
        validator.validate(payload)
        if payload["scope"] == "step" and payload["action"] not in (
            "intent",
            "disposition",
        ):
            phases.append(payload["action"])
        if payload["scope"] == "step" and payload["action"] == "disposition":
            dispositions.append(payload)
    assert sorted(phases) == sorted(
        ["validate", "started", "probe", "stop", "cleanup"] * 2
    )
    assert len(dispositions) == 10 and all(
        p["disposition"] == "completed" for p in dispositions
    )
    receipt = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if receipt:
        (
            Path(receipt) / ("dispatcher-public-" + str(os.getpid()) + ".json")
        ).write_text(
            json.dumps(
                {
                    "events": events,
                    "source_sha256": hashlib.sha256(
                        Path(__file__).read_bytes()
                    ).hexdigest(),
                    "lifecycle_complete": False,
                }
            )
        )
