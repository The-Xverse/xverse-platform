# Scheduler read-only integration findings

18 October 2026. Same-agent separate inspection, not independent full-candidate review.
Record findings before the successor edits that address them.

1. MAJOR composition finding: OutcomeJournal numbers its producer from len(events),
   but that shared retained-mirror register also contains teardown and future step
   producer events. A later probe after a scoped stop/step record would jump its
   producer sequence and fail the client's exact next-sequence check. Retain the
   shared mirror register but give the outcomes producer its own counter. Exercise
   actual interleaved step/tick/stop and health records in full dispatcher tests.
2. ADVISORY scope: already-issued unit composition does not establish initial
   bootstrap/environment admission, full helper closure, restart/recovery, U7/U8,
   global M1, nine runtime cases or independent full review/acceptance. Preserve all
   open full P3 tasks and downstream phases 4–9.
3. MINOR initial expected fixture: 20 active seconds in the two-unit fixture still
   fits 128 calls (100 worst-case calls); the test wrongly expects rejection.
   Use 40 seconds for the over-cap control and retain exact independent counts.
4. MAJOR pure-admission inspection: individually finite, tiny positive cadence
   values can make active_seconds/period overflow to infinity before ceil().
   Reject nonfinite or over-cap derived slot counts explicitly with ScheduleError
   before constructing health obligations. Do not loosen any cadence or limit.
