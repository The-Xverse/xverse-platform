#define OWNED_MODE 0
#define OWNED_TARGET "/dev/shm/maestro-platform-20261021t-qidd24kx/tmpdir/pytest-of-jefferson/pytest-2/test_native_stream_fault_prese0/argus/events.jsonl"
#define OWNED_TRACE "/dev/shm/maestro-platform-20261021t-qidd24kx/tmpdir/pytest-of-jefferson/pytest-2/test_native_stream_fault_prese0/owned-stream-syscalls.jsonl"
