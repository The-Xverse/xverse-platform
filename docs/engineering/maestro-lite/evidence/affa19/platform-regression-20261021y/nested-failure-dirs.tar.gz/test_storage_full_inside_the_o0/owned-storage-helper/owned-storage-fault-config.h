#define OWNED_ARM_AT_LOAD 0
#define OWNED_PREFIX 0
#define OWNED_TARGET "/dev/shm/maestro-platform-20261021t-qidd24kx/tmpdir/pytest-of-jefferson/pytest-2/test_storage_full_inside_the_o0/argus/events.jsonl"
#define OWNED_TRACE "/dev/shm/maestro-platform-20261021t-qidd24kx/tmpdir/pytest-of-jefferson/pytest-2/test_storage_full_inside_the_o0/owned-storage-syscalls.jsonl"
