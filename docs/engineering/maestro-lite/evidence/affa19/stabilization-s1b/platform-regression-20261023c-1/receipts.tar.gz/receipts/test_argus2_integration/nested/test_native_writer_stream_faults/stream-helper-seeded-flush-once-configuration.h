#define OWNED_MODE 1
#define OWNED_TARGET "/dev/shm/maestro-platform-20261021t-uyimqo8l/tmpdir/pytest-of-jefferson/pytest-2/test_native_stream_fault_prese1/argus/events.jsonl"
#define OWNED_TRACE "/dev/shm/maestro-platform-20261021t-uyimqo8l/tmpdir/pytest-of-jefferson/pytest-2/test_native_stream_fault_prese1/owned-stream-syscalls.jsonl"
