#define OWNED_MODE 2
#define OWNED_TARGET "/dev/shm/maestro-platform-20261021t-zcqg_yru/basetemp/test_native_stream_fault_prese2/argus/events.jsonl"
#define OWNED_TRACE "/dev/shm/maestro-platform-20261021t-zcqg_yru/basetemp/test_native_stream_fault_prese2/owned-stream-syscalls.jsonl"
