#define OWNED_MODE 0
#define OWNED_TARGET "/dev/shm/maestro-platform-20261021t-c5zz5pjj/basetemp/test_native_stream_fault_prese0/argus/events.jsonl"
#define OWNED_TRACE "/dev/shm/maestro-platform-20261021t-c5zz5pjj/basetemp/test_native_stream_fault_prese0/owned-stream-syscalls.jsonl"
