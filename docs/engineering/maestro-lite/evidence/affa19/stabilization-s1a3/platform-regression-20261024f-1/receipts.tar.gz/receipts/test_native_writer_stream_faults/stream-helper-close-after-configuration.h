#define OWNED_MODE 3
#define OWNED_TARGET "/dev/shm/maestro-platform-20261021t-ttilxe4c/basetemp/test_native_stream_fault_prese3/argus/events.jsonl"
#define OWNED_TRACE "/dev/shm/maestro-platform-20261021t-ttilxe4c/basetemp/test_native_stream_fault_prese3/owned-stream-syscalls.jsonl"
