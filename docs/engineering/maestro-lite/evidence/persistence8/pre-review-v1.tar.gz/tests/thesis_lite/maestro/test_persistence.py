from dataclasses import replace
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import socket
import subprocess
import sys
import time

import pytest

from xverse.argus import EvidenceStore
from xverse.argus.schema import canonical_bytes
from xverse.maestro.admission import permit_digest
from xverse.maestro.owner import GateConnection, ReleaseOwner, StageSupervisor
from xverse.maestro.persistence import (
    PersistenceClient,
    encode_configuration,
    sealed_input_fd,
)
from xverse.maestro.prbc import BoundaryDescriptor
from xverse.maestro.time import HostDeadline
from xverse_xdl.lifecycle import FileEvidenceJournal
from .test_admission import context
from .test_boundary import environment as environment
from .test_boundary import native as native
from .test_releasegate import guard_binary as guard_binary


def deadline(seconds=3):
    return HostDeadline("host-session", time.monotonic() + seconds)


def configuration(tmp_path, manager):
    prepared, result, resources, bindings, approvals = context()
    now = datetime.now(timezone.utc)
    new_bindings, new_approvals = [], []
    for binding, approval in zip(bindings, approvals):
        permit = replace(
            binding.permit,
            not_before=now - timedelta(seconds=30),
            expires_at=now + timedelta(seconds=60),
        )
        new_bindings.append(replace(binding, generation=1, permit=permit))
        new_approvals.append(
            replace(
                approval,
                generation=1,
                permit_content_digest=permit_digest(permit),
                not_before=now - timedelta(seconds=30),
                expires_at=now + timedelta(seconds=60),
            )
        )
    return encode_configuration(
        prepared,
        result,
        resources,
        run_id="fixture-run",
        bindings=new_bindings,
        approvals=new_approvals,
        session="host-session",
        generation_deadline=manager._admission.teardown_deadline,
        journal_path=tmp_path / "m3.jsonl",
        evidence_root=tmp_path / "argus",
    )


@pytest.fixture
def storage(tmp_path, environment):
    factory, spawn, root = environment
    manager, latch = factory(seconds=30, run_id="fixture-run")
    config = configuration(tmp_path, manager)
    clients, children, gates = [], [], []

    def start(mode=None):
        parent, child = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        parent.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
        cfg = sealed_input_fd(config)
        announce, announce_write = os.pipe()
        release_read, release = os.pipe()
        if mode:
            command = [
                sys.executable,
                "-I",
                str(Path(__file__).with_name("persistence_fixture.py")),
                str(child.fileno()),
                str(cfg),
                str(announce_write),
                str(release_read),
                mode,
            ]
            inherited = (child.fileno(), cfg, announce_write, release_read)
        else:
            command = [
                sys.executable,
                "-I",
                "-m",
                "xverse.maestro.persistence_worker",
                str(child.fileno()),
                str(cfg),
            ]
            inherited = (child.fileno(), cfg)
        try:
            process = subprocess.Popen(
                command,
                pass_fds=inherited,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
        finally:
            child.close()
            os.close(cfg)
            os.close(announce_write)
            os.close(release_read)
        children.append((process, parent, announce, release))
        client = PersistenceClient(
            process,
            parent,
            config,
            latch,
            deadline=deadline(1.5 if mode and mode.startswith("init") else 3),
        )
        clients.append(client)
        owner = ReleaseOwner.from_persistence(
            client, StageSupervisor(manager, latch), latch
        )
        return owner, client, announce, release

    def stage(owner, binary, fixture):
        unit_id = config.prepared.units[0].unit_id
        descriptor = BoundaryDescriptor("fixture-run", unit_id, 1, "remote-owned", 0)
        manager.create_frozen(descriptor)
        child, marker, line = spawn(fixture, manager, descriptor)
        assert line.startswith("CHILD ")
        parent, peer = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        parent.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
        fd = manager._entries[descriptor.key].fd
        artifact = "sha256:" + hashlib.sha256(binary.read_bytes()).hexdigest()
        scope = owner.scope(unit_id, descriptor, artifact)
        until = time.monotonic_ns() + 4_000_000_000
        try:
            gate_process = subprocess.Popen(
                [
                    str(binary),
                    str(fd),
                    str(peer.fileno()),
                    str(config.generation_ns),
                    str(until),
                    "500000000",
                    scope.hex(),
                    "0",
                ],
                pass_fds=(fd, peer.fileno()),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        finally:
            peer.close()
        connection = GateConnection(
            gate_process,
            parent,
            scope=scope,
            epoch=0,
            lease_ns=until,
            artifact_digest=artifact,
            latch=latch,
            deadline=deadline(1),
        )
        gates.append(connection)
        return unit_id, descriptor, child, marker, connection

    yield start, stage, config, manager, latch
    for gate in gates:
        gate.cancel("test-teardown")
        gate.channel.close()
        gate.process.wait(timeout=2)
        gate.dispose()
    for client in clients:
        if not client._failed and not client._aborted:
            client.abort(deadline(1))
        result = client.drain(deadline(1))
        assert result.worker_reaped
        client.dispose()
    reaped = []
    for process, channel, announce, release in children:
        channel.close()
        os.close(announce)
        os.close(release)
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()  # Test bootstrap's original direct child only.
            process.wait(timeout=2)
            pytest.fail("external test bootstrap kill required")
        assert process.stderr.read() == b""
        process.stderr.close()
        reaped.append(process.pid)
    receipt_dir = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if receipt_dir:
        (
            Path(receipt_dir)
            / (
                "persistence-children-"
                + str(os.getpid())
                + "-"
                + tmp_path.name
                + ".json"
            )
        ).write_text(
            json.dumps(
                {
                    "all_children_reaped": True,
                    "storage_children": len(reaped),
                    "gate_children": len(gates),
                }
            )
        )


def test_isolated_actual_m3_argus_to_native_release(
    storage, native, guard_binary, tmp_path
):
    start, stage, config, manager, latch = storage
    owner, client, announce, release = start()
    unit_id = config.prepared.units[0].unit_id
    original = deadline(3)
    event_id = owner.commit_intent(unit_id, original)
    unit_id, descriptor, child, marker, gate = stage(owner, guard_binary, native)
    assert not select.select([marker], [], [], 0.02)[0]
    result = owner.release(unit_id, descriptor, gate, original)
    assert result.native_unfreeze_observed and not result.ready_for_execution
    assert select.select([marker], [], [], 1)[0] and os.read(marker, 1) == b"M"
    owner.cancel()
    assert manager.force_cleanup(descriptor).termination_observed
    assert child.wait(timeout=2) == 0
    assert client.abort(deadline(1)) == "failed"
    assert client.drain(deadline(1)).worker_reaped
    reader = EvidenceStore.read_run(tmp_path / "argus" / "fixture-run")
    records = reader.records()
    payload = records[0]["extensions"]["xverse.maestro"]
    assert records[0]["eventId"] == event_id
    public = FileEvidenceJournal(tmp_path / "m3.jsonl").public_records()[0]
    assert (
        payload["sourceRefs"][0]["sha256"]
        == "sha256:" + hashlib.sha256(canonical_bytes(public)).hexdigest()
    )
    assert reader.manifest.writer_state == "failed"
