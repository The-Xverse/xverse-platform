"""Original typed transport over real BS17/AFFA; no M3 admission claim."""

from dataclasses import replace
import copy
import os
import signal
import threading

import pytest
from xverse.maestro.affa_client import AuthorityConnection
from xverse.maestro.affa_protocol import AuthorityFrame, AuthorityKind as K
from .test_run_bootstrap import (
    run_stack as run_stack,
    run_bootstrap_binary as run_bootstrap_binary,
)
from .test_affa_native import authority_binary as authority_binary
from .test_boundary import environment as environment
from .test_launcher import binaries as binaries, deadline


def connect(stack, monkeypatch):
    session, manager, h, helper, _, _, _ = stack
    for unit in h.units:
        session.watch(unit["descriptor"], deadline(2))
    config = replace(
        h.config,
        scope=session.authority_scope,
        supervisor_session=session.authority_supervisor,
    )
    client = session.authority(config, helper, deadline(2))
    assert type(client) is AuthorityConnection
    h.config = config

    def exchange(frame, fds=()):
        until = h.end()
        if frame.kind is K.RELEASE:
            until = min(until, h.units[frame.slot - 1]["ticket_end"])
        response = client._exchange(
            replace(
                frame,
                sequence=client.sequence + 1,
                deadline_ns=until,
                epoch=client.epoch,
            ),
            fds=fds,
        )
        if response.kind is K.CANCELLED:
            h.closed = True
        return response

    h.rpc = exchange
    for i, unit in enumerate(h.units):
        record = config.units[i]
        frame = AuthorityFrame(
            K.REGISTER,
            1,
            h.end(),
            config.scope,
            i + 1,
            config.epoch,
            1,
            first=record.binding,
            second=record.image,
            third=record.recipe,
            fourth=unit["boundary"],
        )
        assert (
            exchange(
                frame, (unit["cg"], h.image.descriptor, h.cwd, unit["recipe"])
            ).kind
            is K.REGISTERED
        )
    for i in range(2):
        assert exchange(h.frame(K.INTENT, i)).kind is K.INTENT_RECORDED
    return client


def test_typed_original_two_unit_lifecycle(run_stack, monkeypatch):
    client = connect(run_stack, monkeypatch)
    _, _, h, _, _, _, _ = run_stack
    for i in range(2):
        h.stage(i)
        h.arm(i)
        assert h.release(i).kind is K.RELEASED
    h.cancel()
    for i in range(2):
        h.stop_retire(i)
    assert client.epoch == 1 and len(client._pidfds) == 2


def test_client_refuses_a_copied_or_forked_holder(run_stack, monkeypatch):
    client = connect(run_stack, monkeypatch)
    with pytest.raises(TypeError):
        copy.copy(client)
    pid = os.fork()
    if pid == 0:
        try:
            with pytest.raises(ValueError):
                client._holder()
        except BaseException:
            os._exit(1)
        os._exit(0)
    assert os.waitpid(pid, 0)[1] == 0


def test_release_cannot_extend_original_arm_end(run_stack, monkeypatch):
    client = connect(run_stack, monkeypatch)
    _, _, h, _, _, _, _ = run_stack
    h.stage(0)
    h.arm(0)
    frame = replace(
        h.frame(K.RELEASE, 0),
        sequence=client.sequence + 1,
        deadline_ns=h.units[0]["ticket_end"] + 1,
        ticket=h.units[0]["ticket"],
    )
    before = client.sequence
    with pytest.raises(ValueError, match="TICKET-END"):
        client._exchange(frame)
    assert client.sequence == before


def test_independent_revocation_during_stopped_native_exchange(run_stack, monkeypatch):
    client = connect(run_stack, monkeypatch)
    session, _, h, _, _, _, _ = run_stack
    h.stage(0)
    child = client.child
    signal.pidfd_send_signal(child._capability.fileno(), signal.SIGSTOP)
    entered = threading.Event()
    original = client._receive
    errors = []

    def receive(*args, **kwargs):
        entered.set()
        return original(*args, **kwargs)

    monkeypatch.setattr(client, "_receive", receive)

    def query():
        try:
            h.rpc(h.frame(K.QUERY, 0))
        except ValueError as error:
            errors.append(str(error))

    thread = threading.Thread(target=query)
    thread.start()
    try:
        assert entered.wait(1)
        result = client.revoke(deadline(1))
        assert result.issuer_reaped and result.issuer_dead
        assert not result.workload_waits_known and not result.boundaries_released
    finally:
        thread.join(2)
    assert not thread.is_alive() and errors and session.latch.cancelled
