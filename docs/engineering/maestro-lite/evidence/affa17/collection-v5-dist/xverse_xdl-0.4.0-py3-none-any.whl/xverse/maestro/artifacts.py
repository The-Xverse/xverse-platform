"""Bounded declared-file collection; no provider, cleanup or execution authority."""

from dataclasses import dataclass, field
import hashlib
import os
import re
import stat
import threading
import time
from functools import wraps

from .time import HostDeadline


class CollectionError(ValueError):
    pass


def _serialized(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        if not self._lock.acquire(False):
            raise CollectionError('ML-COLLECTION-CONFLICT')
        try:
            return method(self, *args, **kwargs)
        finally:
            self._lock.release()
    return guarded


def _parts(path):
    if (type(path) is not str or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._/-]{0,255}', path) is None
        or any(p in ('', '.', '..') for p in path.split('/'))):
        raise CollectionError('ML-COLLECTION-PATH')
    return path.split('/')


def _identity(fd):
    s = os.fstat(fd)
    return s.st_dev, s.st_ino


def _file_state(fd):
    s = os.fstat(fd)
    return s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns


def _root(path):
    path = os.fspath(path)
    if not os.path.isabs(path) or '..' in path.split('/'):
        raise CollectionError('ML-COLLECTION-ROOT')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for part in path.split('/'):
            if part in ('', '.'):
                continue
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


@dataclass(frozen=True)
class ArtifactDeclaration:
    unit_id: str
    generation: int
    source: str
    destination: str
    required: bool = True
    media_type: str = 'application/octet-stream'

    def __post_init__(self):
        if (type(self.unit_id) is not str or not 1 <= len(self.unit_id) <= 512
            or type(self.generation) is not int or not 1 <= self.generation <= 128
            or type(self.required) is not bool or type(self.media_type) is not str
            or re.fullmatch(r'[A-Za-z0-9.+-]+/[A-Za-z0-9.+-]+', self.media_type) is None):
            raise CollectionError('ML-COLLECTION-DECLARATION')
        _parts(self.source)
        _parts(self.destination)


@dataclass(frozen=True)
class CollectedArtifact:
    declaration: ArtifactDeclaration
    status: str
    content: bytes | None = field(repr=False)
    sha256: str | None = None
    diagnostic: str | None = None


@dataclass(frozen=True)
class CollectionResult:
    artifacts: tuple[CollectedArtifact, ...]

    @property
    def collection_complete(self):
        return all(a.status == 'collected' or (a.status == 'missing' and not a.declaration.required)
                   for a in self.artifacts)


@dataclass(frozen=True)
class IndexedArtifact:
    path: str
    bytes: int
    sha256: str
    media_type: str
    schema_version: str
    role: str

    def public_entry(self):
        return dict(path=self.path, bytes=self.bytes, sha256=self.sha256,
                    mediaType=self.media_type, schemaVersion=self.schema_version, role=self.role)


class CollectionAdmission:
    """Original descriptor pins and immutable declarations; explicitly close after use."""

    def __init__(self, source_root, evidence_root, declarations, deadline):
        declarations = tuple(declarations)
        if len(declarations) > 128 or any(type(d) is not ArtifactDeclaration for d in declarations):
            raise CollectionError('ML-COLLECTION-COUNT')
        units = {d.unit_id for d in declarations}
        if (len(units) > 16 or any(sum(d.unit_id == u for d in declarations) > 8 for u in units)
            or len({d.destination for d in declarations}) != len(declarations)
            or len({(d.unit_id, d.generation, d.source) for d in declarations}) != len(declarations)):
            raise CollectionError('ML-COLLECTION-COUNT')
        if type(deadline) is not HostDeadline:
            raise CollectionError('ML-COLLECTION-DEADLINE')
        deadline.__post_init__()
        if not 0 < deadline.monotonic_seconds - time.monotonic() <= 10:
            raise CollectionError('ML-COLLECTION-DEADLINE')
        self.source_root, self.evidence_root = os.fspath(source_root), os.fspath(evidence_root)
        self.declarations, self.deadline = declarations, deadline
        self._lock = threading.Lock()
        self._source = self._target = None
        try:
            self._source = _root(self.source_root)
            self._target = _root(self.evidence_root)
            if _identity(self._source) == _identity(self._target):
                raise CollectionError('ML-COLLECTION-DISTINCT-ROOTS')
            self._pins = (self._source, _identity(self._source), self._target, _identity(self._target),
                          declarations, deadline, os.getpid())
            self._result = None
            self._indexes = {}
        except BaseException:
            self.close()
            raise

    def __reduce_ex__(self, protocol):
        raise TypeError('original collection admission cannot be copied')

    def _scope(self, deadline):
        if (type(deadline) is not HostDeadline or deadline.session != self.deadline.session
            or deadline.monotonic_seconds > self.deadline.monotonic_seconds
            or os.getpid() != self._pins[6] or self.declarations is not self._pins[4]
            or self.deadline is not self._pins[5] or self._source != self._pins[0]
            or self._target != self._pins[2]):
            raise CollectionError('ML-COLLECTION-ORIGINAL')
        deadline.__post_init__()

    def _check(self, deadline):
        self._scope(deadline)
        if time.monotonic() >= deadline.monotonic_seconds:
            raise CollectionError('ML-COLLECTION-TIMEOUT')
        for path, fd, identity in [(self.source_root, self._source, self._pins[1]),
                                    (self.evidence_root, self._target, self._pins[3])]:
            try:
                current = _root(path)
            except OSError as error:
                raise CollectionError('ML-COLLECTION-ROOT-CHANGED') from error
            try:
                if _identity(current) != identity or _identity(fd) != identity:
                    raise CollectionError('ML-COLLECTION-ROOT-CHANGED')
            finally:
                os.close(current)

    def _parent_live(self, root, path, parent, deadline):
        self._check(deadline)
        try:
            current, _ = self._parent(root, path, deadline)
        except OSError as error:
            raise CollectionError('ML-COLLECTION-PARENT-CHANGED') from error
        try:
            if _identity(current) != _identity(parent):
                raise CollectionError('ML-COLLECTION-PARENT-CHANGED')
        finally:
            os.close(current)

    def _parent(self, root, path, deadline):
        parts = _parts(path)
        fd = os.dup(root)
        try:
            for part in parts[:-1]:
                self._check(deadline)
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                os.close(fd)
                fd = child
            return fd, parts[-1]
        except BaseException:
            os.close(fd)
            raise

    def _read(self, declaration, deadline, remaining):
        parent, name = self._parent(self._source, declaration.source, deadline)
        fd = None
        try:
            self._check(deadline)
            try:
                fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
            except FileNotFoundError:
                self._parent_live(self._source, declaration.source, parent, deadline)
                raise
            before = _file_state(fd)
            if not stat.S_ISREG(before[2]):
                raise CollectionError('ML-COLLECTION-NONREGULAR')
            if before[3] > min(1 << 20, remaining):
                raise CollectionError('ML-COLLECTION-SIZE')
            chunks = []
            size = 0
            while True:
                self._check(deadline)
                chunk = os.read(fd, min(65536, before[3] - size + 1))
                if not chunk:
                    break
                size += len(chunk)
                if size > before[3]:
                    raise CollectionError('ML-COLLECTION-CHANGED')
                chunks.append(chunk)
            self._check(deadline)
            try:
                named = os.stat(name, dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError as error:
                raise CollectionError('ML-COLLECTION-CHANGED') from error
            if (_file_state(fd) != before or size != before[3]
                or (named.st_dev, named.st_ino) != before[:2]):
                raise CollectionError('ML-COLLECTION-CHANGED')
            self._parent_live(self._source, declaration.source, parent, deadline)
            return b''.join(chunks)
        finally:
            if fd is not None:
                os.close(fd)
            os.close(parent)

    def _copy(self, declaration, data, deadline):
        try:
            parent, name = self._parent(self._target, declaration.destination, deadline)
        except OSError as error:
            raise CollectionError('ML-COLLECTION-DESTINATION') from error
        fd = None
        identity = None
        try:
            self._check(deadline)
            fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                         0o600, dir_fd=parent)
            identity = _identity(fd)
            offset = 0
            while offset < len(data):
                self._check(deadline)
                written = os.write(fd, data[offset:offset+65536])
                if written <= 0:
                    raise CollectionError('ML-COLLECTION-WRITE')
                offset += written
            os.fsync(fd)
            self._check(deadline)
            before = _file_state(fd)
            os.lseek(fd, 0, os.SEEK_SET)
            actual = bytearray()
            while len(actual) <= len(data):
                self._check(deadline)
                chunk = os.read(fd, min(65536, len(data)-len(actual)+1))
                if not chunk:
                    break
                actual.extend(chunk)
            named = os.stat(name, dir_fd=parent, follow_symlinks=False)
            if (bytes(actual) != data or (named.st_dev, named.st_ino) != identity
                or _file_state(fd) != before):
                raise CollectionError('ML-COLLECTION-COPY-CHANGED')
            self._parent_live(self._target, declaration.destination, parent, deadline)
            os.fsync(parent)
            self._check(deadline)
        except BaseException as error:
            if identity is not None:
                try:
                    named = os.stat(name, dir_fd=parent, follow_symlinks=False)
                    if (named.st_dev, named.st_ino) == identity:
                        os.unlink(name, dir_fd=parent)
                except OSError:
                    pass
            if isinstance(error, FileNotFoundError):
                raise CollectionError('ML-COLLECTION-DESTINATION') from error
            raise
        finally:
            if fd is not None:
                os.close(fd)
            os.close(parent)

    @_serialized
    def collect(self, deadline):
        self._scope(deadline)
        if self._result is not None:
            return self._result
        self._check(deadline)
        rows = []
        remaining = 16 << 20
        for declaration in self.declarations:
            try:
                self._check(deadline)
                data = self._read(declaration, deadline, remaining)
                remaining -= len(data)
                self._copy(declaration, data, deadline)
                rows.append(CollectedArtifact(declaration, 'collected', data, hashlib.sha256(data).hexdigest()))
            except FileNotFoundError:
                try:
                    self._check(deadline)
                except (CollectionError, OSError) as error:
                    code = str(error) if isinstance(error, CollectionError) else 'ML-COLLECTION-IO'
                    rows.append(CollectedArtifact(declaration, 'error', None, diagnostic=code))
                else:
                    rows.append(CollectedArtifact(declaration, 'missing', None, diagnostic='ML-COLLECTION-MISSING'))
            except (CollectionError, OSError) as error:
                code = str(error) if isinstance(error, CollectionError) else 'ML-COLLECTION-IO'
                rows.append(CollectedArtifact(declaration, 'error', None, diagnostic=code))
        self._result = CollectionResult(tuple(rows))
        return self._result

    @_serialized
    def index(self, writer, result, deadline):
        from xverse.argus import EvidenceRun

        if type(writer) is not EvidenceRun or result is not self._result or result is None:
            raise CollectionError('ML-COLLECTION-ORIGINAL')
        self._scope(deadline)
        prior = self._indexes.get(id(writer))
        if prior is not None and prior[0] is writer:
            return prior[1]
        entries = []
        for row in result.artifacts:
            if row.status != 'collected':
                continue
            self._check(deadline)
            receipt = IndexedArtifact(row.declaration.destination, len(row.content), row.sha256,
                                      row.declaration.media_type, '1.0', 'evidence')
            actual = writer.record_artifact(receipt.path, media_type=receipt.media_type,
                                            schema_version='1.0', role='evidence')
            if actual != receipt.public_entry() or type(actual.get('bytes')) is not int:
                raise CollectionError('ML-COLLECTION-INDEX-ACK')
            self._check(deadline)
            entries.append(receipt)
        entries = tuple(entries)
        self._indexes[id(writer)] = writer, entries
        return entries

    @_serialized
    def close(self):
        for name in ('_source', '_target'):
            fd = getattr(self, name, None)
            if fd is not None:
                os.close(fd)
                setattr(self, name, None)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
