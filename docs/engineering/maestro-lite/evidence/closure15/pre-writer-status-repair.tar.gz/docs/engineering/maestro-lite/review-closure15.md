# Original run closure read-only findings

18 October 2026. Separate same-agent component inspection; independent full-candidate review remains pending. Record findings before successor repairs.

1. MAJOR original-inventory inspection: dictionary identity alone does not pin its
   contents. A substituted adapter could target a foreign original root. Retain an
   immutable birth/client log in the original BootstrapSession and validate it in
   _holder; also bind each retained adapter to the exact original issued child/role
   before any cancellation, write or cleanup. Missing adapters remain explicit.
2. MAJOR mutation inspection: closure currently catches a unit-teardown lock
   conflict and proceeds to destructive cancellation. Reject normal conflicts
   before mutation. Reserve the original owner thread under the existing owner/
   facade/controller locks, then release those locks before invoking teardown;
   maintain the reservation through closure. Independent cancellation stays free.
3. MINOR initial test lint: unused time import; remove before current verification.
4. MAJOR writer-status inspection: an actual open Argus manifest records
   `unassessed`, which is neither complete nor incomplete. The draft decoder would
   reject a valid flush-error response containing that real manifest status.
   Preserve the accepted recorded enum including unassessed; assessed completeness
   stays separate. Require coherent manifest hash/state/status fields. A retained
   role-3 birth without a constructed client needs an explicit unknown writer row,
   rather than an empty writer list suggesting that no writer obligation exists.
