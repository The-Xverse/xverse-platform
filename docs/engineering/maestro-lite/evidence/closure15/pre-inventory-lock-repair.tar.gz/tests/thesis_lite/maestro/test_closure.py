"""Original full-run resource closure; expected controls precede implementation."""

from dataclasses import asdict, replace
import copy
import hashlib
import json
import os
from pathlib import Path
import signal
import time

import pytest
from xverse.argus import EvidenceStore
from xverse.argus.schema import canonical_bytes
from xverse.maestro.run_closure import RunClosure, ClosureError
from xverse.maestro.teardown import ReverseTeardown
from .test_bootstrap import (
    boot_stack as boot_stack,
    supervisor_binary as supervisor_binary,
)
from .test_boundary import environment as environment, native as native
from .test_launcher import binaries as binaries, deadline
from .test_provider import runtime


def retain(result, stack, name):
    root = os.environ.get("MAESTRO_BOUNDARY_RECEIPTS")
    if root:
        reader = EvidenceStore.read_run(stack[4].parent / "argus")
        data = dict(
            result=asdict(result),
            manifest=reader.manifest,
            recorded=reader.recorded_evidence_status,
            assessed=reader.assessed_evidence_status,
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        )
        (Path(root) / f"closure-public-{os.getpid()}-{name}.json").write_text(
            json.dumps(data)
        )


def test_all_original_helpers_and_extra_boundary_close_with_separate_writer_facts(
    boot_stack,
):
    facade, owner, descriptor, launcher, handle, gate, original = runtime(boot_stack)
    root = boot_stack[0]
    extra = boot_stack[5]("extra-unhandled")
    closer = RunClosure(root, teardown=ReverseTeardown(facade))
    until = deadline(7)
    result = closer.close(until)
    assert result.cleanup_complete
    assert len(result.helpers) == 3 and len(result.boundaries) == 5
    assert all(h.process_reaped for h in result.helpers)
    assert next(h for h in result.helpers if h.role == 1).direct_child_reaped
    assert any(b.unit_id == extra.unit_id and b.released for b in result.boundaries)
    writer = result.writers[0]
    assert writer.acknowledged and writer.before_state == "open"
    assert writer.after_state == "failed" and writer.abort_completed
    assert writer.durable_recorded_status == "incomplete"
    reader = EvidenceStore.read_run(boot_stack[4].parent / "argus")
    assert (
        writer.manifest_sha256
        == hashlib.sha256(canonical_bytes(reader.manifest)).hexdigest()
    )
    assert not result.lifecycle_complete and not result.ready_for_execution
    assert closer.close(until) is result
    with pytest.raises(ClosureError):
        closer.close(until, reason="different")
    retain(result, boot_stack, "normal")


def test_partial_bootstrap_closes_exact_resources_without_normal_unit_records(
    boot_stack,
):
    owner, storage, descriptor, launcher, handle, gate, original = boot_stack[6]()
    result = RunClosure(boot_stack[0]).close(deadline(5))
    assert result.cleanup_complete and not result.normal_unit_records_complete
    assert not (boot_stack[4] / "source-binding.marker").exists()
    assert result.writers[0].abort_completed
    retain(result, boot_stack, "staged")


def test_actual_storage_stall_keeps_unknown_state_and_still_closes_owned_boundaries(
    boot_stack,
):
    facade, owner, descriptor, launcher, handle, gate, original = runtime(boot_stack)
    storage = owner.persistence
    signal.pidfd_send_signal(storage.process._capability.fileno(), signal.SIGSTOP)
    result = RunClosure(boot_stack[0], terminal_seconds=0.1).close(deadline(4))
    assert result.cleanup_complete
    writer = result.writers[0]
    assert not writer.acknowledged and writer.after_state is None
    assert writer.last_acknowledged_state == "open"
    assert writer.manifest_sha256 is None and not writer.abort_completed
    retain(result, boot_stack, "storage-stall")


def test_forced_native_issuer_loss_does_not_fabricate_direct_wait(boot_stack):
    facade, owner, descriptor, launcher, handle, gate, original = runtime(boot_stack)
    signal.pidfd_send_signal(launcher.process._capability.fileno(), signal.SIGKILL)
    result = RunClosure(boot_stack[0]).close(deadline(5))
    assert result.root_reaped and all(b.released for b in result.boundaries)
    assert not result.cleanup_complete
    assert next(h for h in result.helpers if h.role == 1).direct_child_reaped is False
    retain(result, boot_stack, "issuer-loss")


@pytest.mark.parametrize(
    "field,value",
    [
        ("terminal_seconds", True),
        ("drain_seconds", 3),
        ("boundary_seconds", float("nan")),
    ],
)
def test_invalid_closure_budget_has_no_effect(boot_stack, field, value):
    with pytest.raises(ClosureError):
        RunClosure(boot_stack[0], **{field: value})
    assert not boot_stack[2].cancelled


def test_normal_conflicts_reject_and_independent_cancel_does_not_wait(boot_stack):
    closer = RunClosure(boot_stack[0])
    boot_stack[0]._lock.acquire()
    try:
        with pytest.raises(ClosureError):
            closer.close(deadline(3))
        assert not boot_stack[2].cancelled
        closer.cancel()
        assert boot_stack[2].cancelled
    finally:
        boot_stack[0]._lock.release()
    result = closer.close(deadline(3))
    assert result.root_reaped


def test_copied_and_changed_scope_reject_before_mutation(boot_stack):
    closer = RunClosure(boot_stack[0])
    with pytest.raises((ValueError, TypeError)):
        copy.copy(closer)
    with pytest.raises(ClosureError):
        closer.close(replace(deadline(3), session="other"))
    assert not boot_stack[2].cancelled


def test_full_dispatcher_result_precedes_full_helper_closure(request, monkeypatch):
    from .test_dispatcher import full_stack, dispatcher, ends

    stack = full_stack(request, monkeypatch)
    driver = dispatcher(stack)
    execution = driver.run(*ends(driver))
    assert execution.execution_succeeded
    result = RunClosure(stack[0], dispatcher=driver).close(deadline(5))
    assert result.execution_succeeded is True and result.cleanup_complete
    assert result.normal_unit_records_complete and len(result.helpers) == 5
    assert result.writers[0].abort_completed
    assert not result.lifecycle_complete
    retain(result, stack, "full-dispatcher")
